package controller;

import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.StringReader;
import java.time.format.DateTimeParseException;


import model.IModelAdvanced;
import model.ModelImpl2;

import static org.junit.Assert.assertEquals;

/**
 * This is a test class for the controller implementation.
 */
public class ControllerImplTest {
  private Appendable out;
  private Readable in;
  private IController controller;
  private IModelAdvanced model;

  @Before
  public void setUp() {
    in = new StringReader("");
    out = new StringBuilder();
    controller = new ControllerImpl2(out, in);
    model = new ModelImpl2();
  }

  @Test
  public void testAddStock() throws IOException {
    String expectedOutput = "Menu options:\n\nTo view g/l type: GainOrLoss\n" +
            "To view moving average type: MovingAverage\n" +
            "To view crossover days: Crossover\n" +
            "To create a new portfolio: CreatePortfolio\n" +
            "To buy a stock to a portfolio: AddStock\n" +
            "To sell a stock from a portfolio: RemoveStock\n" +
            "To return a summary of a portfolio: ReturnPortfolio\n" +
            "To display a graph to analyze a stock or portfolio: VisualizePerformance\n" +
            "To rebalance a portfolio: Rebalance\n" +
            "To locally save a portfolio: SavePortfolio\n" +
            "To import a portfolio: LoadFile\n" +
            "To quit type: q\n" +
            "Enter the name for this portfolio: \n" +
            "Enter creation date (YYYY-MM-DD): \n" +
            "Enter current date (YYYY-MM-DD): \n" +
            "Your portfolio MyPortfolio has been created.\n" +
            "Which portfolio do you want to add to: \n" +
            "Portfolio MyPortfolio selected.\n" +
            "Enter ticker symbol: \n" +
            "Ticker symbol GOOG selected.\n" +
            "Enter quantity: \n" +
            "Enter date of purchase (YYYY-MM-DD): \n" +
            "Stock stored successfully.\n";
    in = new StringReader("CreatePortfolio\n MyPortfolio \n 2020-01-01 \n 2024-04-04 \n AddStock"
            + "\n MyPortfolio \n GOOG \n 50 \n 2022-01-01 \n q");
    controller = new ControllerImpl2(out, in);
    controller.goController(model);
    assertEquals(expectedOutput, out.toString());
  }


  @Test
  public void testCrossover() throws IOException {
    String actual = "Menu options:\n\nTo view g/l type: GainOrLoss\n" +
            "To view moving average type: MovingAverage\n" +
            "To view crossover days: Crossover\n" +
            "To create a new portfolio: CreatePortfolio\n" +
            "To buy a stock to a portfolio: AddStock\n" +
            "To sell a stock from a portfolio: RemoveStock\n" +
            "To return a summary of a portfolio: ReturnPortfolio\n" +
            "To display a graph to analyze a stock or portfolio: VisualizePerformance\n" +
            "To rebalance a portfolio: Rebalance\n" +
            "To locally save a portfolio: SavePortfolio\n" +
            "To import a portfolio: LoadFile\n" +
            "To quit type: q\n" +
            "Enter ticker symbol: \n" +
            "Enter start date (YYYY-MM-DD): \n" +
            "Enter amount of days as an integer: \n" +
            "Moving Average: $120.032\n";
    in = new StringReader("Crossover \n GOOG \n 2023-06-30 \n 7 \n q");
    controller = new ControllerImpl2(out, in);
    controller.goController(model);
    assertEquals(actual, out.toString());
  }

  @Test
  public void testCreatePortfolioSuccessful() throws IOException {
    String expectedOutput = "Menu options:\n\nTo view g/l type: GainOrLoss\n" +
            "To view moving average type: MovingAverage\n" +
            "To view crossover days: Crossover\n" +
            "To create a new portfolio: CreatePortfolio\n" +
            "To buy a stock to a portfolio: AddStock\n" +
            "To sell a stock from a portfolio: RemoveStock\n" +
            "To return a summary of a portfolio: ReturnPortfolio\n" +
            "To display a graph to analyze a stock or portfolio: VisualizePerformance\n" +
            "To rebalance a portfolio: Rebalance\n" +
            "To locally save a portfolio: SavePortfolio\n" +
            "To import a portfolio: LoadFile\n" +
            "To quit type: q\n" +
            "Enter the name for this portfolio: \n" +
            "Enter creation date (YYYY-MM-DD): \n" +
            "Enter current date (YYYY-MM-DD): \n" +
            "Your portfolio BlahBlah has been created.\n";
    in = new StringReader("CreatePortfolio \n BlahBlah \n 2024-01-01 \n 2024-04-04 \n q");
    controller = new ControllerImpl2(out, in);
    controller.goController(model);
    assertEquals(expectedOutput, out.toString());
  }

  @Test
  public void testCreatePortfolioDuplicate() throws IOException {
    String expectedOutput = "Menu options:\n\nTo view g/l type: GainOrLoss\n" +
            "To view moving average type: MovingAverage\n" +
            "To view crossover days: Crossover\n" +
            "To create a new portfolio: CreatePortfolio\n" +
            "To buy a stock to a portfolio: AddStock\n" +
            "To sell a stock from a portfolio: RemoveStock\n" +
            "To return a summary of a portfolio: ReturnPortfolio\n" +
            "To display a graph to analyze a stock or portfolio: VisualizePerformance\n" +
            "To rebalance a portfolio: Rebalance\n" +
            "To locally save a portfolio: SavePortfolio\n" +
            "To import a portfolio: LoadFile\n" +
            "To quit type: q\n" +
            "Enter the name for this portfolio: \n" +
            "Enter creation date (YYYY-MM-DD): \n" +
            "Enter current date (YYYY-MM-DD): \n" +
            "Your portfolio MyNewPortfolio has been created.\n" +
            "Enter the name for this portfolio: \n" +
            "Enter creation date (YYYY-MM-DD): \n" +
            "Enter current date (YYYY-MM-DD): \n" +
            "A portfolio with this name already exists!\n";
    in = new StringReader("CreatePortfolio \n MyNewPortfolio \n 2020-02-02 \n 2024-02-02 \n" +
            "CreatePortfolio \n MyNewPortfolio \n 2020-02-02 \n 2024-02-02\n q");
    controller = new ControllerImpl2(out, in);
    controller.goController(model);
    assertEquals(expectedOutput, out.toString());
  }

  @Test
  public void testGainOrLossCommand() throws IOException {
    String expectedOutput = "Menu options:\n\nTo view g/l type: GainOrLoss\n" +
            "To view moving average type: MovingAverage\n" +
            "To view crossover days: Crossover\n" +
            "To create a new portfolio: CreatePortfolio\n" +
            "To buy a stock to a portfolio: AddStock\n" +
            "To sell a stock from a portfolio: RemoveStock\n" +
            "To return a summary of a portfolio: ReturnPortfolio\n" +
            "To display a graph to analyze a stock or portfolio: VisualizePerformance\n" +
            "To rebalance a portfolio: Rebalance\n" +
            "To locally save a portfolio: SavePortfolio\n" +
            "To import a portfolio: LoadFile\n" +
            "To quit type: q\n" +
            "Enter ticker symbol: \n" +
            "Enter start date (YYYY-MM-DD): \n" +
            "Enter end date (YYYY-MM-DD): \n" +
            "Gain/Loss: $24.44999999999999\n";
    in = new StringReader("GainOrLoss\n AAPL\n 2023-01-26\n 2023-04-27\n q");
    controller = new ControllerImpl2(out, in);

    controller.goController(model);
    assertEquals(expectedOutput, out.toString());
  }

  @Test
  public void testMovingAverage() throws IOException {
    String actual = "Menu options:\n\nTo view g/l type: GainOrLoss\n" +
            "To view moving average type: MovingAverage\n" +
            "To view crossover days: Crossover\n" +
            "To create a new portfolio: CreatePortfolio\n" +
            "To buy a stock to a portfolio: AddStock\n" +
            "To sell a stock from a portfolio: RemoveStock\n" +
            "To return a summary of a portfolio: ReturnPortfolio\n" +
            "To display a graph to analyze a stock or portfolio: VisualizePerformance\n" +
            "To rebalance a portfolio: Rebalance\n" +
            "To locally save a portfolio: SavePortfolio\n" +
            "To import a portfolio: LoadFile\n" +
            "To quit type: q\n" +
            "Enter ticker symbol: \n" +
            "Enter start date (YYYY-MM-DD): \n" +
            "Enter amount of days as an integer: \n" +
            "Moving Average: $123.22809523809524\n";
    in = new StringReader("MovingAverage \n GOOG \n 2023-06-30 \n 30 \n q");
    controller = new ControllerImpl2(out, in);
    try {
      controller.goController(model);
      assertEquals(actual, out.toString());
    } catch (DateTimeParseException e) {
      // expected
    }
    //basically append everything that the output would include, menu and the actual output
    //once go is fixed, just test what out.toString() is and copy paste it
  }

  @Test
  public void testReturnPortfolioCommand() throws IOException {
    String expectedOutput = "Menu options:\n\nTo view g/l type: GainOrLoss\n" +
            "To view moving average type: MovingAverage\n" +
            "To view crossover days: Crossover\n" +
            "To create a new portfolio: CreatePortfolio\n" +
            "To buy a stock to a portfolio: AddStock\n" +
            "To sell a stock from a portfolio: RemoveStock\n" +
            "To return a summary of a portfolio: ReturnPortfolio\n" +
            "To display a graph to analyze a stock or portfolio: VisualizePerformance\n" +
            "To rebalance a portfolio: Rebalance\n" +
            "To locally save a portfolio: SavePortfolio\n" +
            "To import a portfolio: LoadFile\n" +
            "To quit type: q\n" +
            "Enter the name for this portfolio: \n" +
            "Enter creation date (YYYY-MM-DD): \n" +
            "Enter current date (YYYY-MM-DD): \n" +
            "Your portfolio MyPortfolio has been created.\n" +
            "Enter the name of the portfolio you want to view: \n" +
            "Enter start date (YYYY-MM-DD): \n" +
            "Your portfolio MyPortfolio has been selected.\n" +
            "Finding distribution of portfolio on 2023-01-01: \n" +
            "The value of the portfolio today is: $0.00\n" +
            "Your portfolio contains: \n\n";
    in = new StringReader("CreatePortfolio\n MyPortfolio\n 2020-01-01 \n 2024-02-02 \n " +
            "ReturnPortfolio\n MyPortfolio \n 2023-01-01\n q");
    controller = new ControllerImpl2(out, in);
    controller.goController(model);
    assertEquals(expectedOutput, out.toString());
  }


  @Test
  public void testInvalidCommand() throws IOException {
    String expectedOutput = "Menu options:\n\nTo view g/l type: GainOrLoss\n" +
            "To view moving average type: MovingAverage\n" +
            "To view crossover days: Crossover\n" +
            "To create a new portfolio: CreatePortfolio\n" +
            "To buy a stock to a portfolio: AddStock\n" +
            "To sell a stock from a portfolio: RemoveStock\n" +
            "To return a summary of a portfolio: ReturnPortfolio\n" +
            "To display a graph to analyze a stock or portfolio: VisualizePerformance\n" +
            "To rebalance a portfolio: Rebalance\n" +
            "To locally save a portfolio: SavePortfolio\n" +
            "To import a portfolio: LoadFile\n" +
            "To quit type: q\n" +
            "Invalid command. Please try again.\n";
    in = new StringReader("ILoveIceCream!\nq");
    controller = new ControllerImpl2(out, in);
    controller.goController(model);
    assertEquals(expectedOutput, out.toString());
  }

  @Test
  public void testQuickExit() throws IOException {
    String expectedOutput = "Menu options:\n\nTo view g/l type: GainOrLoss\n" +
            "To view moving average type: MovingAverage\n" +
            "To view crossover days: Crossover\n" +
            "To create a new portfolio: CreatePortfolio\n" +
            "To buy a stock to a portfolio: AddStock\n" +
            "To sell a stock from a portfolio: RemoveStock\n" +
            "To return a summary of a portfolio: ReturnPortfolio\n" +
            "To display a graph to analyze a stock or portfolio: VisualizePerformance\n" +
            "To rebalance a portfolio: Rebalance\n" +
            "To locally save a portfolio: SavePortfolio\n" +
            "To import a portfolio: LoadFile\n" +
            "To quit type: q\n";
    in = new StringReader("q");
    controller = new ControllerImpl2(out, in);
    controller.goController(model);
    assertEquals(expectedOutput, out.toString());
  }

  @Test
  public void testVisualization() throws IOException {
    String actual = "Menu options:\n\nTo view g/l type: GainOrLoss\n" +
            "To view moving average type: MovingAverage\n" +
            "To view crossover days: Crossover\n" +
            "To create a new portfolio: CreatePortfolio\n" +
            "To buy a stock to a portfolio: AddStock\n" +
            "To sell a stock from a portfolio: RemoveStock\n" +
            "To return a summary of a portfolio: ReturnPortfolio\n" +
            "To display a graph to analyze a stock or portfolio: VisualizePerformance\n" +
            "To rebalance a portfolio: Rebalance\n" +
            "To locally save a portfolio: SavePortfolio\n" +
            "To import a portfolio: LoadFile\n" +
            "To quit type: q\n" +
            "Enter 'portfolio' or 'stock': \n" +
            "Enter name of the portfolio or stock: \n" +
            "Enter start date (YYYY-MM-DD): \n" +
            "Make sure there are at least 5 days between the start and end dates inclusive: \n" +
            "Enter end date (YYYY-MM-DD): \n" +
            "Performance of ULTA from 2023-06-30 to 2023-07-30\n" +
            "\n" +
            "2023-06-30: ***********************************************\n" +
            "2023-07-06: ***********************************************\n" +
            "2023-07-07: ***********************************************\n" +
            "2023-07-13: ***********************************************\n" +
            "2023-07-14: ***********************************************\n" +
            "2023-07-20: **********************************************\n" +
            "2023-07-21: **********************************************\n" +
            "2023-07-27: ********************************************\n" +
            "2023-07-28: ********************************************\n" +
            "\n" +
            "Scale: * = 10.00\n\n";
    in = new StringReader("VisualizePerformance \n stock \n ULTA \n 2023-06-30 " +
            "\n 2023-07-30 \n q");
    controller = new ControllerImpl2(out, in);
    controller.goController(model);
    assertEquals(actual, out.toString());
  }

  @Test
  public void testAddPortfolioNewController() throws IOException {
    String actual = "Menu options:\n\nTo view g/l type: GainOrLoss\n" +
            "To view moving average type: MovingAverage\n" +
            "To view crossover days: Crossover\n" +
            "To create a new portfolio: CreatePortfolio\n" +
            "To buy a stock to a portfolio: AddStock\n" +
            "To sell a stock from a portfolio: RemoveStock\n" +
            "To return a summary of a portfolio: ReturnPortfolio\n" +
            "To display a graph to analyze a stock or portfolio: VisualizePerformance\n" +
            "To rebalance a portfolio: Rebalance\n" +
            "To locally save a portfolio: SavePortfolio\n" +
            "To import a portfolio: LoadFile\n" +
            "To quit type: q\n" +
            "Enter the name for this portfolio: \n" +
            "Enter creation date (YYYY-MM-DD): \n" +
            "Enter current date (YYYY-MM-DD): \n" +
            "Your portfolio test has been created.\n" +
            "Which portfolio do you want to add to: \n" +
            "Portfolio test selected.\n" +
            "Enter ticker symbol: \n" +
            "Ticker symbol ULTA selected.\n" +
            "Enter quantity: \n" +
            "Enter date of purchase (YYYY-MM-DD): \n" +
            "Stock stored successfully.\n";
    in = new StringReader("CreatePortfolio \n test \n 2023-06-30 \n 2023-07-30 \n " +
            "AddStock \n test \n ULTA \n 2 \n 2023-07-12 \n q");
    controller = new ControllerImpl2(out, in);
    controller.goController(model);
    assertEquals(actual, out.toString());
  }

  @Test
  public void testLoadFile() throws IOException {
    String actual = "Menu options:\n\nTo view g/l type: GainOrLoss\n" +
            "To view moving average type: MovingAverage\n" +
            "To view crossover days: Crossover\n" +
            "To create a new portfolio: CreatePortfolio\n" +
            "To buy a stock to a portfolio: AddStock\n" +
            "To sell a stock from a portfolio: RemoveStock\n" +
            "To return a summary of a portfolio: ReturnPortfolio\n" +
            "To display a graph to analyze a stock or portfolio: VisualizePerformance\n" +
            "To rebalance a portfolio: Rebalance\n" +
            "To locally save a portfolio: SavePortfolio\n" +
            "To import a portfolio: LoadFile\n" +
            "To quit type: q\n" +
            "Make sure the file name is just the tickerSymbol.txt: \n" +
            "Enter the name for the portfolio you want to load: \n" +
            "Portfolio: model.AdvancedPortfolio@6e38921cstored.\n" +
            "Enter the name of the portfolio you want to view: \n" +
            "Enter start date (YYYY-MM-DD): \n" +
            "Your portfolio rn has been selected.\n" +
            "Finding distribution of portfolio on 2023-01-02: \n" +
            "The stock: BTC is worth: $813.89\n" +
            "The stock: AAPL is worth: $1,169.37\n" +
            "On the selected date, market is closed. Finding most recent " +
            "stock data on: 2022-12-30\n" +
            "The value of the portfolio today is: $1,983.26\n" +
            "Your portfolio contains: \n" +
            "The stock BTC has this many shares: 9.0\n" +
            "The stock AAPL has this many shares: 9.0\n\n";
    in = new StringReader("LoadFile \n rn \n ReturnPortfolio \n rn \n 2023-01-02 \n q");
    controller = new ControllerImpl2(out, in);
    controller.goController(model);
    assertEquals(actual, out.toString());
  }

  @Test
  public void testRebalancing() throws IOException {
    String actual = "Menu options:\n\nTo view g/l type: GainOrLoss\n" +
            "To view moving average type: MovingAverage\n" +
            "To view crossover days: Crossover\n" +
            "To create a new portfolio: CreatePortfolio\n" +
            "To buy a stock to a portfolio: AddStock\n" +
            "To sell a stock from a portfolio: RemoveStock\n" +
            "To return a summary of a portfolio: ReturnPortfolio\n" +
            "To display a graph to analyze a stock or portfolio: VisualizePerformance\n" +
            "To rebalance a portfolio: Rebalance\n" +
            "To locally save a portfolio: SavePortfolio\n" +
            "To import a portfolio: LoadFile\n" +
            "To quit type: q\n";
    in = new StringReader("LoadFile \n rn \n ReturnPortfolio \n rn \n 2023-01-02 \n q");
    controller = new ControllerImpl2(out, in);
    controller.goController(model);
    assertEquals(actual, out.toString());
  }
}