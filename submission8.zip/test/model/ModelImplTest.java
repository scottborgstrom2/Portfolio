package model;

import org.junit.Test;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

/**
 * This is the test class for the model implementation.
 */
public class ModelImplTest {

  @Test
  public void testFetchAndAddStock_NoDuplicateAdded() {
    ModelImpl model = new ModelImpl2();
    MockStock mockStock = new MockStock("GOOG");
    model.addStock("GOOG", mockStock);
    model.addStock("TSLA", mockStock);
    model.addStock("GOOG", mockStock);
    model.fetchAndAddStock("GOOG");
    IStock result = model.getStock("GOOG");
    assertEquals(mockStock, result);
  }

  @Test
  public void testFetchAndAddStock_AddStockViaService() {

    ModelImpl model = new ModelImpl2();
    MockAlphaVantageService mockService = new MockAlphaVantageService();

    MockStock expectedStock = new MockStock("AAPL");
    mockService.addStockData("AAPL", expectedStock);

    model.setAlphaVantageService(mockService);

    model.fetchAndAddStock("AAPL");

    IStock actualStock = model.getStock("AAPL");
    assertEquals(expectedStock, actualStock);
  }


  @Test
  public void testFetchAndAddStock_NullTicker() {
    ModelImpl model = new ModelImpl2();
    try {
      model.fetchAndAddStock(null);
      fail("Expected IllegalArgumentException for null ticker");
    } catch (IllegalArgumentException e) {
      // expected
    }
  }

  @Test
  public void testFetchAndAddStock_EmptyTicker() {
    ModelImpl model = new ModelImpl2();
    try {
      model.fetchAndAddStock("");
      fail("Expected IllegalArgumentException for empty ticker");
    } catch (IllegalArgumentException e) {
      // expected
    }
  }

  @Test
  public void testInvalidDateForValueCalc() {
    ModelImpl model = new ModelImpl2();
    String portfolioName = "testPortfolio";
    LocalDate creationDate = LocalDate.of(2020, 1, 1);
    LocalDate currentDate = LocalDate.of(2024, 1, 1);
    LocalDate failDate = LocalDate.of(2012, 1, 1);
    IPortfolio advanced = new AdvancedPortfolio(portfolioName, creationDate, currentDate);
    model.addPortfolioWithValues(advanced);
    assertEquals(0.0, advanced.getPortfolioValue(failDate, model), 0.01);
  }

  @Test
  public void testFetchAndAddStock_InvalidTicker() {
    ModelImpl model = new ModelImpl2();
    try {
      model.fetchAndAddStock("ZSIA");
      fail("Expected IllegalArgumentException for empty ticker");
    } catch (DateTimeParseException e) {
      // expected
    }
  }

  @Test
  public void testAddPortfolio_Success() {
    ModelImpl model = new ModelImpl2();
    String portfolioName = "UniquePortfolio";
    model.addPortfolio(portfolioName);
    assertNotNull("Portfolio should be added", model.getPortfolio(portfolioName));
  }

  @Test
  public void testAddPortfolio_AlreadyExists() {
    ModelImpl model = new ModelImpl2();
    String portfolioName = "ExistingPortfolio";
    model.addPortfolio(portfolioName);
    try {
      model.addPortfolio(portfolioName);
      fail("Expected IllegalArgumentException for duplicate portfolio name");
    } catch (IllegalArgumentException e) {
      assertEquals("Portfolio already exists", e.getMessage());
    }
  }

  @Test
  public void testAddPortfolio_NullName() {
    ModelImpl model = new ModelImpl2();
    try {
      model.addPortfolio(null);
      fail("Expected IllegalArgumentException for null portfolio name");
    } catch (IllegalArgumentException e) {
      assertEquals("Portfolio name cannot be null or empty", e.getMessage());
    }
  }

  @Test
  public void testAddPortfolio_EmptyName() {
    ModelImpl model = new ModelImpl2();
    try {
      model.addPortfolio("");
      fail("Expected IllegalArgumentException for empty portfolio name");
    } catch (IllegalArgumentException e) {
      assertEquals("Portfolio name cannot be null or empty", e.getMessage());
    }
  }

  @Test
  public void testAddStock() {
    ModelImpl model = new ModelImpl2();
    MockStock mockStock = new MockStock("AAPL");
    model.addStock("AAPL", mockStock);
    assertEquals(mockStock, model.getStock("AAPL"));
  }

  @Test
  public void testSetAlphaVantageService() {
    ModelImpl model = new ModelImpl2();
    AlphaVantageService mockService = new MockAlphaVantageService();
    model.setAlphaVantageService(mockService);
    MockStock mockStock = new MockStock("AAPL");
    model.addStock("AAPL", mockStock);
    assertEquals(mockStock, model.getStock("AAPL"));
  }

  @Test
  public void testGetPortfolio_Success() {
    ModelImpl model = new ModelImpl2();
    String portfolioName = "MyPortfolio";
    model.addPortfolio(portfolioName);
    IPortfolio retrievedPortfolio = model.getPortfolio(portfolioName);
    assertNotNull(retrievedPortfolio);
  }

  @Test
  public void testGetPortfolio_Nonexistent() {
    ModelImpl model = new ModelImpl2();
    try {
      model.getPortfolio("Nonexistent");
      fail("Expected IllegalArgumentException for a nonexistent portfolio");
    } catch (IllegalArgumentException e) {
      assertEquals("Portfolio does not exist", e.getMessage());
    }
  }

  @Test
  public void testCalculateGainLoss_StockNotFound() {
    ModelImpl model = new ModelImpl2();
    try {
      model.calculateGainLoss("XZIO", LocalDate.of(2020, 1, 1), LocalDate.of(2020, 1, 10));
      fail("Expected IllegalArgumentException for non-existent stock");
    } catch (IllegalArgumentException e) {
      assertEquals("Stock not found", e.getMessage());
    }
  }

  @Test
  public void testCalculateGainLoss_MissingStartPrice() {
    ModelImpl model = new ModelImpl2();
    MockStock mockStock = new MockStock("AAPL");
    mockStock.addPrice(LocalDate.of(2020, 1, 10), 160.0);  // Only adding price for the end date
    model.addStock("AAPL", mockStock);

    try {
      model.calculateGainLoss("AAPL", LocalDate.of(2020, 1, 1), LocalDate.of(2020, 1, 10));
      fail("Expected IllegalArgumentException for missing start price data");
    } catch (IllegalArgumentException e) {
      assertEquals("Stock price for one of the dates not found", e.getMessage());
    }
  }

  @Test
  public void testCalculateGainLoss_MissingEndPrice() {
    ModelImpl model = new ModelImpl2();
    MockStock mockStock = new MockStock("AAPL");
    mockStock.addPrice(LocalDate.of(2020, 1, 1), 150.0);
    model.addStock("AAPL", mockStock);

    try {
      model.calculateGainLoss("AAPL", LocalDate.of(2020, 1, 1), LocalDate.of(2020, 1, 10));
      fail("Expected IllegalArgumentException for missing end price data");
    } catch (IllegalArgumentException e) {
      assertEquals("Stock price for one of the dates not found", e.getMessage());
    }
  }

  @Test
  public void testCalculateGainLoss_PriceIsZero() {
    ModelImpl model = new ModelImpl2();
    MockStock mockStock = new MockStock("AAPL");
    mockStock.addPrice(LocalDate.of(2020, 1, 1), 0.0);
    mockStock.addPrice(LocalDate.of(2020, 1, 10), 160.0);
    model.addStock("AAPL", mockStock);

    try {
      model.calculateGainLoss("AAPL", LocalDate.of(2020, 1, 1), LocalDate.of(2020, 1, 10));
      fail("Expected IllegalArgumentException for zero price data");
    } catch (IllegalArgumentException e) {
      assertEquals("Stock price for one of the dates not found", e.getMessage());
    }
  }

  @Test
  public void testCalculateGainLoss_InvalidDateRange() {
    ModelImpl model = new ModelImpl2();
    MockStock mockStock = new MockStock("AAPL");
    mockStock.addPrice(LocalDate.of(2020, 1, 1), 150.0);
    mockStock.addPrice(LocalDate.of(2020, 1, 10), 160.0);
    model.addStock("AAPL", mockStock);

    try {
      model.calculateGainLoss("AAPL", LocalDate.of(2020, 1,
              10), LocalDate.of(2020, 1, 1));
      fail("Expected IllegalArgumentException for invalid date range");
    } catch (IllegalArgumentException e) {
      assertEquals("End date must not be before start date", e.getMessage());
    }
  }

  @Test
  public void testCalculateMovingAverage_Success() {
    ModelImpl model = new ModelImpl2();
    MockStock mockStock = new MockStock("AAPL");
    LocalDate start = LocalDate.of(2020, 1, 10);
    for (int i = 0; i < 5; i++) {
      mockStock.addPrice(start.minusDays(i), 10 * i + 100);
    }
    model.addStock("AAPL", mockStock);

    double movingAverage = model.calculateMovingAverage("AAPL", start, 5);
    assertEquals(120.0, movingAverage, 0.01);  // Expected average
  }

  @Test
  public void testCalculateMovingAverage_StockNotFound() {
    ModelImpl model = new ModelImpl2();
    try {
      model.calculateMovingAverage("NONEXISTENT", LocalDate.now(), 5);
      fail("Expected IllegalArgumentException for non-existent stock");
    } catch (IllegalArgumentException e) {
      assertEquals("Stock not found", e.getMessage());
    }
  }

  @Test
  public void testCalculateMovingAverage_MissingData() {
    ModelImpl model = new ModelImpl2();
    MockStock mockStock = new MockStock("AAPL");
    LocalDate start = LocalDate.of(2020, 1, 10);
    mockStock.addPrice(start, 200.0);
    mockStock.addPrice(start.minusDays(1), 180.0);
    mockStock.addPrice(start.minusDays(4), 160.0);
    model.addStock("AAPL", mockStock);

    double movingAverage = model.calculateMovingAverage("AAPL", start, 5);
    assertEquals(180.0, movingAverage, 0.01);
  }

  @Test
  public void testCalculateMovingAverage_InvalidDays() {
    ModelImpl model = new ModelImpl2();
    MockStock mockStock = new MockStock("AAPL");
    mockStock.addPrice(LocalDate.of(2020, 1, 10), 150.0);
    model.addStock("AAPL", mockStock);

    try {
      model.calculateMovingAverage("AAPL", LocalDate.of(2020, 1,
              10), 0);
      fail("Expected IllegalArgumentException for zero days");
    } catch (IllegalArgumentException e) {
      assertEquals("Number of days must be positive", e.getMessage());
    }
  }

  @Test
  public void testCalculateMovingAverage_AllPricesZero() {
    ModelImpl model = new ModelImpl2();
    MockStock mockStock = new MockStock("AAPL");
    LocalDate start = LocalDate.of(2020, 1, 10);
    for (int i = 0; i < 5; i++) {
      mockStock.addPrice(start.minusDays(i), 0.0);
    }
    model.addStock("AAPL", mockStock);

    try {
      model.calculateMovingAverage("AAPL", start, 5);
      fail("Expected IllegalArgumentException for all zero prices");
    } catch (IllegalArgumentException e) {
      assertEquals("No valid price data found within the specified days", e.getMessage());
    }
  }

  @Test
  public void testCalculateCrossover_Success() {
    ModelImpl model = new ModelImpl2();
    MockStock mockStock = new MockStock("AAPL");
    LocalDate start = LocalDate.of(2020, 1, 1);
    for (int i = 0; i < 10; i++) {
      mockStock.addPrice(start.plusDays(i), 100 + i * 10);
    }
    model.addStock("AAPL", mockStock);

    List<LocalDate> crossovers = model.calculateCrossover("AAPL", start,
            start.plusDays(9), 3);
    assertTrue(crossovers.contains(start.plusDays(2)));
    assertTrue(crossovers.contains(start.plusDays(3)));
  }

  @Test
  public void testCalculateCrossover_StockNotFound() {
    ModelImpl model = new ModelImpl2();
    try {
      model.calculateCrossover("USDIOP", LocalDate.now(), LocalDate.now().plusDays(1), 5);
      fail("Expected IllegalArgumentException for non-existent stock");
    } catch (IllegalArgumentException e) {
      assertEquals("Stock not found", e.getMessage());
    }
  }

  @Test
  public void testCalculateCrossover_NoCrossovers() {
    ModelImpl model = new ModelImpl2();
    MockStock mockStock = new MockStock("AAPL");
    LocalDate start = LocalDate.of(2020, 1, 1);
    for (int i = 0; i < 10; i++) {
      mockStock.addPrice(start.plusDays(i), 100);
    }
    model.addStock("AAPL", mockStock);

    try {
      model.calculateCrossover("AAPL", start, start.plusDays(9), 3);
      fail("Expected IllegalArgumentException for no crossovers found");
    } catch (IllegalArgumentException e) {
      assertEquals("No cross dates found", e.getMessage());
    }
  }

  @Test
  public void testCalculateCrossover_InvalidDateRange() {
    ModelImpl2 model = new ModelImpl2();
    LocalDate start = LocalDate.of(2020, 1, 10);
    LocalDate end = LocalDate.of(2020, 1, 5);

    try {
      model.calculateCrossover("AAPL", start, end, 5);
      fail("Expected IllegalArgumentException for invalid date range");
    } catch (IllegalArgumentException e) {
      assertEquals("End date must not be before start date", e.getMessage());
    }
  }

  @Test
  public void testGetStock_StockExists() {
    ModelImpl2 model = new ModelImpl2();
    MockStock expectedStock = new MockStock("AAPL");
    model.addStock("AAPL", expectedStock);

    IStock retrievedStock = model.getStock("AAPL");
    assertEquals("The retrieved stock should be the one that was added",
            expectedStock, retrievedStock);
  }

  @Test
  public void testGetStock_StockDoesNotExist() {
    ModelImpl2 model = new ModelImpl2();
    try {
      IStock retrievedStock = model.getStock("OAISFA");
      fail("should fail");
    } catch (Exception e) {
      //will try to fetch but instead reaches an exception that we catch.
    }
  }

  @Test
  public void testGetStock_NullTicker() {
    ModelImpl2 model = new ModelImpl2();
    try {
      model.getStock(null);
      fail("Expected IllegalArgumentException for null ticker symbol");
    } catch (IllegalArgumentException e) {
      assertEquals("Ticker symbol cannot be null or empty", e.getMessage());
    }
  }

  @Test
  public void testGetStock_EmptyTicker() {
    ModelImpl model = new ModelImpl2();
    try {
      model.getStock("");
      fail("Expected IllegalArgumentException for empty ticker symbol");
    } catch (IllegalArgumentException e) {
      assertEquals("Ticker symbol cannot be null or empty", e.getMessage());
    }
  }







  @Test
  public void testAddPortfolioAdvanced_Success() {
    ModelImpl2 model = new ModelImpl2();
    String portfolioName = "AdvancedPortfolio";
    model.addPortfolioAdvanced(portfolioName, LocalDate.of(2022, 1, 1), LocalDate.of(2023, 1, 1));
    assertNotNull("Advanced portfolio should be added", model.getPortfolio(portfolioName));
  }

  @Test
  public void testAddPortfolioAdvanced_AlreadyExists() {
    ModelImpl2 model = new ModelImpl2();
    String portfolioName = "ExistingAdvancedPortfolio";
    model.addPortfolioAdvanced(portfolioName, LocalDate.of(2022, 1, 1), LocalDate.of(2023, 1, 1));
    try {
      model.addPortfolioAdvanced(portfolioName, LocalDate.of(2022, 1, 1), LocalDate.of(2023, 1, 1));
      fail("Expected IllegalArgumentException for duplicate advanced portfolio name");
    } catch (IllegalArgumentException e) {
      assertEquals("Portfolio already exists", e.getMessage());
    }
  }

  @Test
  public void testAddPortfolioAdvanced_NullName() {
    ModelImpl2 model = new ModelImpl2();
    try {
      model.addPortfolioAdvanced(null, LocalDate.of(2022, 1, 1), LocalDate.of(2023, 1, 1));
      fail("Expected IllegalArgumentException for null portfolio name");
    } catch (IllegalArgumentException e) {
      assertEquals("Portfolio name cannot be null or empty", e.getMessage());
    }
  }

  @Test
  public void testAddPortfolioAdvanced_EmptyName() {
    ModelImpl2 model = new ModelImpl2();
    try {
      model.addPortfolioAdvanced("", LocalDate.of(2022, 1, 1), LocalDate.of(2023, 1, 1));
      fail("Expected IllegalArgumentException for empty portfolio name");
    } catch (IllegalArgumentException e) {
      assertEquals("Portfolio name cannot be null or empty", e.getMessage());
    }
  }

  @Test
  public void testAddPortfolioAdvanced_NullDates() {
    ModelImpl2 model = new ModelImpl2();
    try {
      model.addPortfolioAdvanced("NullDatesPortfolio", null, LocalDate.of(2023, 1, 1));
      fail("Expected IllegalArgumentException for null creation date");
    } catch (IllegalArgumentException e) {
      assertEquals("Creation or current date is null", e.getMessage());
    }

    try {
      model.addPortfolioAdvanced("NullDatesPortfolio", LocalDate.of(2022, 1, 1), null);
      fail("Expected IllegalArgumentException for null current date");
    } catch (IllegalArgumentException e) {
      assertEquals("Creation or current date is null", e.getMessage());
    }
  }

  @Test
  public void testVisualizeStockPerformance() {
    ModelImpl2 model = new ModelImpl2();
    String expectedOutput = "Performance of AAPL from 2022-01-01 to 2022-01-05\n" +
            "\n" +
            "2022-01-01: ***************\n" +
            "2022-01-05: ***************\n" +
            "\n" +
            "Scale: * = 10.00\n";

    // Add a mock stock for testing
    MockStock mockStock = new MockStock("AAPL");
    mockStock.addPrice(LocalDate.of(2022, 1, 1), 150.0);
    mockStock.addPrice(LocalDate.of(2022, 1, 2), 152.0);
    mockStock.addPrice(LocalDate.of(2022, 1, 3), 154.0);
    mockStock.addPrice(LocalDate.of(2022, 1, 4), 156.0);
    mockStock.addPrice(LocalDate.of(2022, 1, 5), 158.0);
    model.addStock("AAPL", mockStock);

    // Visualize performance for the stock over these days
    String barChartStock = model.visualizePerformance("AAPL",
            LocalDate.of(2022, 1, 1),
            LocalDate.of(2022, 1, 5), false);
    assertEquals(expectedOutput, barChartStock);

  }

  @Test
  public void testVisualizePortfolioPerformance() {
    ModelImpl2 model = new ModelImpl2();
    String expectedOutput = "Performance of test from 2022-01-01 to 2022-01-05\n" +
            "\n" +
            "2022-01-01: *********\n" +
            "2022-01-05: *********\n" +
            "\n" +
            "Scale: * = 1000.00\n";

    // Add a portfolio for testing
    model.addPortfolioAdvanced("test", LocalDate.of(2020, 1, 1),
            LocalDate.of(2022, 1, 5));

    IPortfolio portfolio = model.getPortfolio("test");
    portfolio.addStock("AAPL", 7, LocalDate.of(2021, 1, 1));
    portfolio.addStock("GOOG", 3, LocalDate.of(2021, 1, 1));
    // Visualize performance for the stock over these days
    String barChartStock = model.visualizePerformance("test", LocalDate.of(2022, 1, 1),
            LocalDate.of(2022, 1, 5), true);
    assertEquals(expectedOutput, barChartStock);

  }


  @Test
  public void testRebalancePortfolio() {
    ModelImpl2 model = new ModelImpl2();
    String expectedString = "The stock AAPL has this many shares: 4.666666666666667\n" +
            "The stock TSLA has this many shares: 10.5\n";
    model.addPortfolioAdvanced("test", LocalDate.of(2022, 1, 1), LocalDate.of(2024, 1, 5));
    IPortfolio portfolioToGrab = model.getPortfolio("test");
    Map<String, Integer> weights = new HashMap<>();
    weights.put("AAPL", 40);
    weights.put("TSLA", 60);
    portfolioToGrab.addStock("AAPL", 7, LocalDate.of(2023, 1, 5));
    portfolioToGrab.addStock("TSLA", 7, LocalDate.of(2023, 1, 5));

    MockStock aaplStock = new MockStock("AAPL");
    MockStock tslaStock = new MockStock("TSLA");
    aaplStock.addPrice(LocalDate.of(2024, 1, 1), 150.0);
    tslaStock.addPrice(LocalDate.of(2024, 1, 1), 100.0);
    model.addStock("AAPL", aaplStock);
    model.addStock("TSLA", tslaStock);

    model.rebalancedPortfolio("test", LocalDate.of(2024, 1, 1), weights);
    IPortfolio portfolioPostBalance = model.getPortfolio("test");
    assertEquals(expectedString, portfolioPostBalance.getPortfolioSummary());
  }

  @Test
  public void testRebalancePortfolioBadWeights() {
    ModelImpl2 model = new ModelImpl2();
    String expectedString = "The stock AAPL has this many shares: 8.166666666666666\n" +
            "The stock TSLA has this many shares: 10.5\n";
    model.addPortfolioAdvanced("test", LocalDate.of(2022, 1, 1), LocalDate.of(2024, 1, 5));
    IPortfolio portfolioToGrab = model.getPortfolio("test");
    Map<String, Integer> weights = new HashMap<>();
    weights.put("AAPL", 70);
    weights.put("TSLA", 60);
    portfolioToGrab.addStock("AAPL", 7, LocalDate.of(2023, 1, 5));
    portfolioToGrab.addStock("TSLA", 7, LocalDate.of(2023, 1, 5));

    MockStock aaplStock = new MockStock("AAPL");
    MockStock tslaStock = new MockStock("TSLA");
    aaplStock.addPrice(LocalDate.of(2024, 1, 1), 150.0);
    tslaStock.addPrice(LocalDate.of(2024, 1, 1), 100.0);
    model.addStock("AAPL", aaplStock);
    model.addStock("TSLA", tslaStock);

    try {
      model.rebalancedPortfolio("test", LocalDate.of(2024, 1, 1), weights);
    } catch (IllegalArgumentException e) {
      fail("test rebalancedPortfolio exception");
    }

    IPortfolio postBalance = model.getPortfolio("test");
    assertEquals(expectedString, postBalance.getPortfolioSummary());
  }


  @Test
  public void testCountStock() {
    ModelImpl2 model = new ModelImpl2();
    String portfolioName = "TestPortfolio";
    model.addPortfolio(portfolioName);
    IPortfolio portfolio = model.getPortfolio(portfolioName);
    portfolio.addStock("AAPL", 7, LocalDate.of(2023, 1, 5));
    portfolio.addStock("TSLA", 7, LocalDate.of(2023, 1, 5));

    int expectedSize = 2;
    int result = model.countStock(portfolioName);
    assertEquals(expectedSize, result);
  }
}
