package model;

import org.junit.Before;
import org.junit.Test;

import java.time.LocalDate;
import java.util.Map;

import static org.junit.Assert.assertEquals;

/**
 * This is the test class for the Stock.
 */
public class StockTest {
  private IStock stock;

  @Before
  public void setUp() {
    stock = new Stock("AAPL");
  }

  @Test
  public void testGetTickerSymbol() {
    assertEquals("AAPL", stock.getTickerSymbol());
  }

  @Test
  public void testAddAndRetrievePrice() {
    LocalDate date = LocalDate.of(2020, 1, 1);
    double price = 150.0;
    stock.addPrice(date, price);
    assertEquals(price, stock.getPrice(date), 0.01);
  }

  @Test
  public void testRetrieveDefaultPrice() {
    LocalDate date = LocalDate.of(2020, 1, 2);
    assertEquals(0.0, stock.getPrice(date), 0.01);
  }

  @Test
  public void testAddAndRetrieveMultiplePrices() {
    LocalDate date1 = LocalDate.of(2020, 1, 1);
    LocalDate date2 = LocalDate.of(2020, 1, 2);
    double price1 = 150.0;
    double price2 = 155.0;
    stock.addPrice(date1, price1);
    stock.addPrice(date2, price2);
    assertEquals(price1, stock.getPrice(date1), 0.01);
    assertEquals(price2, stock.getPrice(date2), 0.01);
  }

  @Test
  public void testRetrievePriceForNonExistentDate() {
    LocalDate date = LocalDate.of(2020, 1, 3);
    assertEquals(0.0, stock.getPrice(date), 0.01);
  }

  @Test
  public void testBoundaryDates() {
    LocalDate startDate = LocalDate.of(2020, 1, 1);
    LocalDate endDate = LocalDate.of(2020, 12, 31);
    double startPrice = 100.0;
    double endPrice = 200.0;
    stock.addPrice(startDate, startPrice);
    stock.addPrice(endDate, endPrice);
    assertEquals(startPrice, stock.getPrice(startDate), 0.01);
    assertEquals(endPrice, stock.getPrice(endDate), 0.01);
  }

  @Test
  public void testZeroAndNegativePrices() {
    LocalDate date = LocalDate.of(2020, 1, 1);
    stock.addPrice(date, 0.0);
    assertEquals(0.0, stock.getPrice(date), 0.01);
    stock.addPrice(date, -100.0);
    assertEquals(-100.0, stock.getPrice(date), 0.01);
  }

  @Test
  public void testGetPerformanceData() {
    LocalDate startDate = LocalDate.of(2024, 6, 1);
    LocalDate endDate = LocalDate.of(2024, 6, 10);

    stock.addPrice(LocalDate.of(2024, 6, 1), 700.0);
    stock.addPrice(LocalDate.of(2024, 6, 2), 710.0);
    stock.addPrice(LocalDate.of(2024, 6, 3), 720.0);
    stock.addPrice(LocalDate.of(2024, 6, 4), 730.0);
    stock.addPrice(LocalDate.of(2024, 6, 5), 740.0);
    stock.addPrice(LocalDate.of(2024, 6, 6), 750.0);
    stock.addPrice(LocalDate.of(2024, 6, 7), 760.0);
    stock.addPrice(LocalDate.of(2024, 6, 8), 770.0);
    stock.addPrice(LocalDate.of(2024, 6, 9), 780.0);
    stock.addPrice(LocalDate.of(2024, 6, 10), 790.0);

    Map<LocalDate, Double> performanceData = stock.getPerformanceData(startDate, endDate);

    assertEquals(10, performanceData.size());

    assertEquals(700.0, performanceData.get(LocalDate.of(2024, 6, 1)), 0.01);
    assertEquals(710.0, performanceData.get(LocalDate.of(2024, 6, 2)), 0.01);
    assertEquals(720.0, performanceData.get(LocalDate.of(2024, 6, 3)), 0.01);
    assertEquals(730.0, performanceData.get(LocalDate.of(2024, 6, 4)), 0.01);
    assertEquals(740.0, performanceData.get(LocalDate.of(2024, 6, 5)), 0.01);
    assertEquals(750.0, performanceData.get(LocalDate.of(2024, 6, 6)), 0.01);
    assertEquals(760.0, performanceData.get(LocalDate.of(2024, 6, 7)), 0.01);
    assertEquals(770.0, performanceData.get(LocalDate.of(2024, 6, 8)), 0.01);
    assertEquals(780.0, performanceData.get(LocalDate.of(2024, 6, 9)), 0.01);
    assertEquals(790.0, performanceData.get(LocalDate.of(2024, 6, 10)), 0.01);
  }

}