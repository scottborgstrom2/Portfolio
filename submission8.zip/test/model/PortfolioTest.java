package model;

import org.junit.Test;
import java.time.LocalDate;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

/**
 * This is the test class for the Portfolio.
 */
public class PortfolioTest {
  @Test
  public void testAddStockValidQuantity() {
    Portfolio portfolio = new Portfolio("MyPortfolio");
    portfolio.addStock("AAPL", 10,
            LocalDate.of(2022, 1, 1));
    assertEquals(10.0, portfolio.
            getStockQuantity("AAPL"), 0.01);
  }

  @Test
  public void testAddStockExistingStock() {
    Portfolio portfolio = new Portfolio("MyPortfolio");
    portfolio.addStock("AAPL", 5, LocalDate.of(2022, 1, 1));
    portfolio.addStock("AAPL", 5, LocalDate.of(2022, 1, 1));
    assertEquals(10.0, portfolio.
            getStockQuantity("AAPL"), 0.01);
  }

  @Test
  public void testAddStockNegativeQuantity() {
    Portfolio portfolio = new Portfolio("MyPortfolio");
    try {
      portfolio.addStock("AAPL", -5, LocalDate.of(2022, 1, 1));
      fail("Expected IllegalArgumentException for negative quantity");
    } catch (IllegalArgumentException e) {
      assertEquals("Quantity must be greater than 0", e.getMessage());
    }
  }

  @Test
  public void testAddStockZeroQuantity() {
    Portfolio portfolio = new Portfolio("MyPortfolio");
    try {
      portfolio.addStock("AAPL", 0, LocalDate.of(2022, 1, 1));
      fail("Expected IllegalArgumentException for zero quantity");
    } catch (IllegalArgumentException e) {
      assertEquals("Quantity must be greater than 0", e.getMessage());
    }
  }

  @Test
  public void testRemoveStockValidQuantity() {
    Portfolio portfolio = new Portfolio("MyPortfolio");
    portfolio.addStock("AAPL", 10, LocalDate.of(2022, 1, 1));
    portfolio.removeStock("AAPL", 5, LocalDate.of(2022, 1, 1));
    assertEquals(5.0, portfolio.
            getStockQuantity("AAPL"), 0.01);
  }

  @Test
  public void testRemoveStockMoreThanOwned() {
    Portfolio portfolio = new Portfolio("MyPortfolio");
    portfolio.addStock("AAPL", 5, LocalDate.of(2022, 1, 1));
    try {
      portfolio.removeStock("AAPL", 10, LocalDate.of(2022, 1, 1));
      fail("Expected IllegalArgumentException for removing more than owned");
    } catch (IllegalArgumentException e) {
      assertEquals("Attempting to remove more than you own", e.getMessage());
    }
  }

  @Test
  public void testRemoveStockNotInPortfolio() {
    Portfolio portfolio = new Portfolio("MyPortfolio");
    try {
      portfolio.removeStock("AAPL", 5, LocalDate.of(2022, 1, 1));
      fail("Expected IllegalArgumentException for stock not in portfolio");
    } catch (IllegalArgumentException e) {
      assertEquals("Ticker symbol in this" +
              " portfolio doesn't exist or quantity is invalid", e.getMessage());
    }
  }

  @Test
  public void testRemoveStockExactQuantity() {
    Portfolio portfolio = new Portfolio("MyPortfolio");
    portfolio.addStock("AAPL", 10, LocalDate.of(2022, 1, 1));
    portfolio.removeStock("AAPL", 9, LocalDate.of(2022, 1, 1));
    assertEquals(portfolio.getTotalQuantity("AAPL", LocalDate.of(2022, 2, 1)),
            1.0, 0.01);
    portfolio.removeStock("AAPL", 1, LocalDate.of(2022, 2, 3));
    try {
      portfolio.getStockQuantity("AAPL");
    } catch (Exception e) {
      // quantity has to be greater than 1 to get;
    }
  }

  @Test
  public void testRemoveStockZeroQuantity() {
    Portfolio portfolio = new Portfolio("MyPortfolio");
    portfolio.addStock("AAPL", 10, LocalDate.of(2022, 1, 1));
    try {
      portfolio.removeStock("AAPL", 0, LocalDate.of(2022, 1, 1));
      fail("Expected IllegalArgumentException for zero quantity");
    } catch (IllegalArgumentException e) {
      assertEquals("Ticker symbol in this portfolio " +
              "doesn't exist or quantity is invalid", e.getMessage());
    }
  }

  @Test
  public void testRemoveStockNegativeQuantity() {
    Portfolio portfolio = new Portfolio("MyPortfolio");
    try {
      portfolio.removeStock("AAPL", -5, LocalDate.of(2022, 1, 1));
      fail("Expected IllegalArgumentException for negative quantity");
    } catch (IllegalArgumentException e) {
      assertEquals("Ticker symbol in this portfolio " +
              "doesn't exist or quantity is invalid", e.getMessage());
    }
  }

  @Test
  public void testGetPortfolioValue() {
    Portfolio portfolio = new Portfolio("MyPortfolio");
    portfolio.addStock("AAPL", 10, LocalDate.of(2022, 1, 1));
    portfolio.addStock("TSLA", 5, LocalDate.of(2022, 1, 1));

    ModelImpl model = new ModelImpl();
    MockStock aaplStock = new MockStock("AAPL");
    MockStock tslaStock = new MockStock("TSLA");

    aaplStock.addPrice(LocalDate.now(), 150.0);
    tslaStock.addPrice(LocalDate.now(), 1000.0);

    model.addStock("AAPL", aaplStock);
    model.addStock("TSLA", tslaStock);

    double expectedValue = 1500.0 + 5000.0;
    assertEquals(expectedValue, portfolio.
            getPortfolioValue(LocalDate.now(), model), 0.01);
  }

  @Test
  public void testGetPortfolioValueStockNotFound() {
    Portfolio portfolio = new Portfolio("MyPortfolio");
    portfolio.addStock("AAPL", 10, LocalDate.of(2022, 1, 1));

    ModelImpl model = new ModelImpl();

    try {
      portfolio.getPortfolioValue(LocalDate.now(), model);
    } catch (IllegalArgumentException e) {
      assertEquals("Stock symbol AAPL not found", e.getMessage());
    }
  }

  @Test
  public void testGetPortfolioValueZeroInitialPrice() {
    Portfolio portfolio = new Portfolio("MyPortfolio");
    portfolio.addStock("AAPL", 10, LocalDate.of(2022, 1, 1));

    ModelImpl model = new ModelImpl();
    MockStock aaplStock = new MockStock("AAPL");
    aaplStock.addPrice(LocalDate.now(), 0.0);
    aaplStock.addPrice(LocalDate.now().minusDays(1), 150.0);

    model.addStock("AAPL", aaplStock);

    double expectedValue = 1500.0;
    assertEquals(expectedValue, portfolio.
            getPortfolioValue(LocalDate.now(), model), 0.01);
  }

  @Test
  public void testGetPortfolioValueWithMultipleStocks() {
    Portfolio portfolio = new Portfolio("MyPortfolio");
    portfolio.addStock("AAPL", 10, LocalDate.of(2022, 1, 1));
    portfolio.addStock("TSLA", 5, LocalDate.of(2022, 1, 1));

    ModelImpl model = new ModelImpl();
    MockStock aaplStock = new MockStock("AAPL");
    MockStock tslaStock = new MockStock("TSLA");

    aaplStock.addPrice(LocalDate.now(), 150.0);
    tslaStock.addPrice(LocalDate.now(), 1000.0);

    model.addStock("AAPL", aaplStock);
    model.addStock("TSLA", tslaStock);

    double expectedValue = 1500.0 + 5000.0;  // 10 * 150 + 5 * 1000
    assertEquals(expectedValue, portfolio.
            getPortfolioValue(LocalDate.now(), model), 0.01);
  }

  @Test
  public void testGetPortfolioValueEmptyPortfolio() {
    Portfolio portfolio = new Portfolio("MyPortfolio");

    ModelImpl model = new ModelImpl();
    // No stocks added to the portfolio

    double expectedValue = 0.0;
    assertEquals(expectedValue, portfolio.
            getPortfolioValue(LocalDate.now(), model), 0.01);
  }

  @Test
  public void testGetStockQuantityExistingStock() {
    Portfolio portfolio = new Portfolio("MyPortfolio");
    portfolio.addStock("AAPL", 10,
            LocalDate.of(2022, 1, 1));
    assertEquals(10.0, portfolio.
            getStockQuantity("AAPL"), 0.01);
  }

  @Test
  public void testGetStockQuantityNonExistingStock() {
    Portfolio portfolio = new Portfolio("MyPortfolio");
    try {
      portfolio.getStockQuantity("AAPL");
      fail("should fail");
    } catch (Exception e) {
      //catchs a null stock point
    }
  }

  @Test
  public void testGetPortfolioSummaryEmpty() {
    Portfolio portfolio = new Portfolio("MyPortfolio");
    assertEquals("", portfolio.getPortfolioSummary());
  }

  @Test
  public void testGetPortfolioSummaryWithStocks() {
    Portfolio portfolio = new Portfolio("MyPortfolio");
    portfolio.addStock("AAPL", 10, LocalDate.of(2022, 1, 1));
    portfolio.addStock("TSLA", 5, LocalDate.of(2022, 1, 1));
    String expectedSummary = "The stock AAPL has this many shares: 10.0\n" +
            "The stock TSLA has this many shares: 5.0\n";
    assertEquals(expectedSummary, portfolio.getPortfolioSummary());
  }

  @Test
  public void testGetPortfolioName() {
    Portfolio portfolio = new Portfolio("MyPortfolio");
    assertEquals("MyPortfolio", portfolio.getPortfolioName());
  }








  @Test
  public void testAdvancedValueBeforeCreation() {
    ModelImpl2 model = new ModelImpl2();
    Portfolio portfolio = new AdvancedPortfolio("me", LocalDate.of(2022, 1, 1),
            LocalDate.of(2024, 2, 2));
    assertEquals("me", portfolio.getPortfolioName());
    assertEquals(LocalDate.of(2022, 1, 1), portfolio.getDateOfCreation());
    assertEquals(LocalDate.of(2024, 2, 2), portfolio.getCurrentDate());
    assertEquals(0.0, portfolio.getPortfolioValue(LocalDate.of(2019,1,1), model), 0.01);
  }

  @Test
  public void testGetPortfolioValueBeforeCreation() {
    ModelImpl model = new ModelImpl();
    AdvancedPortfolio portfolio = new AdvancedPortfolio("AdvancedPortfolio",
            LocalDate.of(2022, 1, 1), LocalDate.of(2022, 12, 31));
    portfolio.addStock("AAPL", 10, LocalDate.of(2022, 1, 1));

    double expectedValue = 0.0;
    assertEquals(expectedValue,
            portfolio.getPortfolioValue(LocalDate.of(2021, 12, 31), model), 0.01);
  }

  @Test
  public void testGetPortfolioValueAfterCreation() {
    ModelImpl model = new ModelImpl();
    AdvancedPortfolio portfolio = new AdvancedPortfolio("AdvancedPortfolio",
            LocalDate.of(2022, 1, 1), LocalDate.of(2022, 12, 31));
    portfolio.addStock("AAPL", 10, LocalDate.of(2022, 1, 1));

    MockStock aaplStock = new MockStock("AAPL");
    aaplStock.addPrice(LocalDate.of(2022, 1, 1), 150.0);
    model.addStock("AAPL", aaplStock);

    double expectedValue = 1500.0;  // 10 * 150
    assertEquals(expectedValue, portfolio.getPortfolioValue(LocalDate.of(2022, 1, 1), model), 0.01);
  }

  @Test
  public void testDistributionOfPortfolioBeforeCreation() {
    ModelImpl model = new ModelImpl();
    AdvancedPortfolio portfolio = new AdvancedPortfolio("AdvancedPortfolio",
            LocalDate.of(2022, 1, 1), LocalDate.of(2022, 12, 31));
    portfolio.addStock("AAPL", 10, LocalDate.of(2022, 1, 1));

    String expectedDistribution = "Distribution not found. Date is before date of creation";
    assertEquals(expectedDistribution,
            portfolio.distributionOfPortfolio(LocalDate.of(2021, 12, 31), model));
  }

  @Test
  public void testDistributionOfPortfolioAfterCreation() {
    ModelImpl model = new ModelImpl();
    AdvancedPortfolio portfolio = new AdvancedPortfolio("AdvancedPortfolio",
            LocalDate.of(2022, 1, 1), LocalDate.of(2022, 12, 31));
    portfolio.addStock("AAPL", 10, LocalDate.of(2022, 1, 1));

    MockStock aaplStock = new MockStock("AAPL");
    aaplStock.addPrice(LocalDate.of(2022, 1, 1), 150.0);
    model.addStock("AAPL", aaplStock);

    String expectedDistribution = "Finding distribution of portfolio on 2022-01-01: \n" +
            "The stock: AAPL is worth: $1,500.00\n" +
            "The value of the portfolio today is: $1,500.00";
    assertEquals(expectedDistribution,
            portfolio.distributionOfPortfolio(LocalDate.of(2022, 1, 1), model));
  }

  @Test
  public void testGetDateOfCreation() {
    AdvancedPortfolio portfolio = new AdvancedPortfolio("AdvancedPortfolio",
            LocalDate.of(2022, 1, 1), LocalDate.of(2022, 12, 31));
    assertEquals(LocalDate.of(2022, 1, 1), portfolio.getDateOfCreation());
  }

  @Test
  public void testGetCurrentDate() {
    AdvancedPortfolio portfolio = new AdvancedPortfolio("AdvancedPortfolio",
            LocalDate.of(2022, 1, 1), LocalDate.of(2022, 12, 31));
    assertEquals(LocalDate.of(2022, 12, 31), portfolio.getCurrentDate());
  }

  @Test
  public void testGetPortfolioSummaryWithCurrentDate() {
    AdvancedPortfolio portfolio = new AdvancedPortfolio("AdvancedPortfolio",
            LocalDate.of(2022, 1, 1), LocalDate.of(2022, 12, 31));
    portfolio.addStock("AAPL", 10, LocalDate.of(2022, 1, 1));
    portfolio.addStock("TSLA", 5, LocalDate.of(2022, 1, 1));

    String expectedSummary = "The stock AAPL has this many shares: 10.0\n" +
            "The stock TSLA has this many shares: 5.0\n";
    assertEquals(expectedSummary, portfolio.getPortfolioSummary());
  }

  @Test
  public void testGetStockQuantityWithCurrentDate() {
    AdvancedPortfolio portfolio = new AdvancedPortfolio("AdvancedPortfolio",
            LocalDate.of(2022, 1, 1), LocalDate.of(2022, 12, 31));
    portfolio.addStock("AAPL", 10, LocalDate.of(2022, 1, 1));
    assertEquals(10.0, portfolio.getStockQuantity("AAPL"), 0.01);
  }

  @Test
  public void testShiftThisStock() {
    AdvancedPortfolio portfolio = new AdvancedPortfolio("AdvancedPortfolio",
            LocalDate.of(2022, 1, 1), LocalDate.of(2022, 12, 31));
    portfolio.addStock("AAPL", 10, LocalDate.of(2022, 1, 1));
    portfolio.shiftThisStock(15, "AAPL", LocalDate.of(2022, 1, 1));
    assertEquals(15.0, portfolio.getStockQuantity("AAPL"), 0.01);

    portfolio.shiftThisStock(5, "AAPL", LocalDate.of(2022, 1, 1));
    assertEquals(5.0, portfolio.getStockQuantity("AAPL"), 0.01);
  }
}