package model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * ModelImpl is an implementation of the model to handle the logic and computations of the program.
 */
public class ModelImpl implements IModel {
  protected Map<String, IStock> stocks;
  protected Map<String, IPortfolio> portfolios;
  protected AlphaVantageService alphaVantageService;

  /**
   * Creates an instance object of an implementation of the model.
   */
  public ModelImpl() {
    this.stocks = new HashMap<>();
    this.portfolios = new HashMap<>();
    this.alphaVantageService = new AlphaVantageService();
  }

  //fetches and add a stock if the ticker is not already contained
  @Override
  public void fetchAndAddStock(String tickerSymbol) {
    // check for null or empty tickerSymbol
    if (tickerSymbol == null || tickerSymbol.isEmpty()) {
      throw new IllegalArgumentException("Ticker symbol cannot be null or empty");
    }
    if (!stocks.containsKey(tickerSymbol)) {
      try {
        IStock stock = LocalDataReader.fetchStockData(tickerSymbol);
        stocks.put(stock.getTickerSymbol(), stock);
      } catch (Exception e) {
        IStock stock = alphaVantageService.fetchStockData(tickerSymbol);
        stocks.put(stock.getTickerSymbol(), stock);
      }
    }
  }

  @Override
  public void addPortfolio(String portfolioName) {
    // added in a check for null or empty portfolio name
    if (portfolioName == null || portfolioName.isEmpty()) {
      throw new IllegalArgumentException("Portfolio name cannot be null or empty");
    }
    if (!portfolios.containsKey(portfolioName)) {
      portfolios.put(portfolioName, new Portfolio(portfolioName));
    } else {
      throw new IllegalArgumentException("Portfolio already exists");
    }
  }

  @Override
  public void addPortfolioWithValues(IPortfolio portfolio) {
    portfolios.put(portfolio.getPortfolioName(), portfolio);
  }

  // Add stocks for testing
  public void addStock(String tickerSymbol, IStock stock) {
    this.stocks.put(tickerSymbol, stock);
  }

  // needed to test fetchAndAddStock without AlphaVantageService
  public void setAlphaVantageService(AlphaVantageService service) {
    this.alphaVantageService = service;
  }

  @Override
  public IPortfolio getPortfolio(String portfolioName) {
    if (portfolios.containsKey(portfolioName)) {
      return portfolios.get(portfolioName);
    } else {
      throw new IllegalArgumentException("Portfolio does not exist");
    }
  }


  //calculates the gain loss and throws an exception if the stock or price data isn't found
  @Override
  public double calculateGainLoss(String tickerSymbol, LocalDate startDate, LocalDate endDate) {
    if (endDate.isBefore(startDate)) {
      throw new IllegalArgumentException("End date must not be before start date");
    }

    IStock stock = stocks.get(tickerSymbol);
    if (stock == null) {
      throw new IllegalArgumentException("Stock not found");
    }
    Double startPrice = stock.getPrice(startDate);
    Double endPrice = stock.getPrice(endDate);
    if (startPrice == null || endPrice == null || startPrice == 0.0 || endPrice == 0.0) {
      throw new IllegalArgumentException("Stock price for one of the dates not found");
    }

    return endPrice - startPrice;
  }

  //calculates the moving average
  @Override
  public double calculateMovingAverage(String tickerSymbol, LocalDate date, int days) {
    if (days <= 0) {
      throw new IllegalArgumentException("Number of days must be positive");
    }

    IStock stock = stocks.get(tickerSymbol);
    if (stock == null) {
      throw new IllegalArgumentException("Stock not found");
    }
    LocalDate startDate = date;
    double total = 0.0;
    int counterDenom = 0;

    for (int i = 0; i < days; i++) {
      Double tempPrice = stock.getPrice(startDate);
      if (tempPrice != null && tempPrice > 0) {
        total += tempPrice;
        counterDenom++;
      }
      startDate = startDate.minusDays(1);
    }

    if (counterDenom == 0) {
      throw new IllegalArgumentException("No valid price data found within the specified days");
    }

    return total / counterDenom;
  }


  @Override
  public List<LocalDate> calculateCrossover(String tickerSymbol, LocalDate startDate,
                                            LocalDate endDate, int x) {
    if (endDate.isBefore(startDate)) {
      throw new IllegalArgumentException("End date must not be before start date");
    }

    IStock stock = stocks.get(tickerSymbol);
    if (stock == null) {
      throw new IllegalArgumentException("Stock not found");
    }

    List<LocalDate> rangeOfDates = new ArrayList<>();
    List<LocalDate> crossDates = new ArrayList<>();
    LocalDate tempDate = startDate;

    while (!tempDate.isAfter(endDate)) {
      rangeOfDates.add(tempDate);
      tempDate = tempDate.plusDays(1);
    }

    for (LocalDate crossDate : rangeOfDates) {
      double price = stock.getPrice(crossDate);
      double movingAverageOfPastXDays = this.calculateMovingAverage(tickerSymbol, crossDate, x);
      if (price > movingAverageOfPastXDays) {
        crossDates.add(crossDate);
      }
    }
    if (crossDates.isEmpty()) {
      throw new IllegalArgumentException("No cross dates found");
    }
    return crossDates;
  }


  @Override
  public IStock getStock(String tickerSymbol) {
    if (tickerSymbol == null || tickerSymbol.isEmpty()) {
      throw new IllegalArgumentException("Ticker symbol cannot be null or empty");
    }
    if (stocks.get(tickerSymbol) == null) {
      fetchAndAddStock(tickerSymbol);
      return stocks.get(tickerSymbol);
    }
    return stocks.get(tickerSymbol);
  }
}