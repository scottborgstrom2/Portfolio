package model;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.LocalDate;
import java.util.Scanner;

/**
 * AlphaVantage is a class to request data from an API.
 * It creates a stock containing the data from a database.
 */
public class AlphaVantageService {
  //updated to use high limit API key
  private static final String API_KEY = "DS89BZRW3DXUEFKT";

  /**
   * The constructor to create a new stock under the ticker symbol.
   * @param stockSymbol is the ticker to find inside the DB.
   *     Returns a new IStock with the proper data.
   */
  public IStock fetchStockData(String stockSymbol) {
    IStock stock = new Stock(stockSymbol);
    URL url = null;

    try {
      url = new URL("https://www.alphavantage.co/query?function=TIME_SERIES_DAILY" +
              "&outputsize=full&symbol=" + stockSymbol + "&apikey=" + API_KEY + "&datatype=csv");
    } catch (MalformedURLException e) {
      throw new RuntimeException("The Alpha Vantage API did not work correctly.");
    }

    try (InputStream in = url.openStream(); Scanner scanner = new Scanner(in)) {
      scanner.nextLine();
      while (scanner.hasNextLine()) {
        String line = scanner.nextLine();
        String[] data = line.split(",");
        LocalDate date = LocalDate.parse(data[0]);
        double closingPrice = Double.parseDouble(data[4]);
        stock.addPrice(date, closingPrice);
      }
    } catch (IOException e) {
      throw new IllegalArgumentException("No price data found for " + stockSymbol);
    }

    return stock;
  }
}
