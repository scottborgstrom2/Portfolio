package model;

import java.time.LocalDate;
import java.util.Map;

/**
 * IStock is the interface to represent any type of stock in the US stock market.
 */
public interface IStock {

  /**
   * This returns the ticker symbol for any given stock.
   */
  String getTickerSymbol();

  /**
   * Adds a price to a stock on a given date.
   *
   * @param date  is the date of which you want to retrieve.
   * @param price is the price at which to input.
   */
  void addPrice(LocalDate date, double price);

  /**
   * Retrieves the price of a stock on a given date.
   *
   * @param date is the date you want to observe the price of.
   */
  Double getPrice(LocalDate date);


  /**
   * getPerformance finds all the non-zero prices of a stock between two dates and stores.
   * it in a map to be handled and utilized for visualization.
   * @param startDate is the first date to consider prices.
   * @param endDate is the last date to consider prices.
   */
  Map<LocalDate, Double> getPerformanceData(LocalDate startDate, LocalDate endDate);

}
