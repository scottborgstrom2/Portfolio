package model;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

/**
 * MockStock is a class to represent a mock to test the controller.
 * and confirm inputs with.
 */
public class MockStock extends Stock {
  private String tickerSymbol;
  private Map<LocalDate, Double> prices;

  /**
   * This creates a code object of type MockStock.
   *
   * @param tickerSymbol is the symbol of the ticker to consider.
   */
  public MockStock(String tickerSymbol) {
    super(tickerSymbol);
    this.prices = new HashMap<>();
  }

  @Override
  public void addPrice(LocalDate date, double price) {
    prices.put(date, price);
  }

  @Override
  public Double getPrice(LocalDate date) {
    return prices.get(date);
  }

  /**
   * Returns all the prices but does not allow direct access.
   */
  public Map<LocalDate, Double> getPrices() {
    return new HashMap<LocalDate, Double>(prices);
  }
}
