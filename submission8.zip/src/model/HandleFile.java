package model;

import java.io.FileNotFoundException;
import java.io.File;
import java.io.FileWriter;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 * HandleFile is a class meant to deal with all instances of saving and writing files.
 * It is capable of parsing through a text file and creating a text file for the user.
 */
public class HandleFile {
  private File file;
  private IPortfolio portfolio; //check if this is OK
  private final IModel model;
  private Map<String, List<PurchaseRecord>> quantities;

  /**
   * Constructor meant for a file as an input.
   * @param file is the file the user passes in.
   * @param model is the model to deal with the logic in.
   */
  public HandleFile(File file, IModel model) {
    this.file = file;
    this.model = model;
    this.quantities = new HashMap<>();
  }

  /**
   * Constructor meant for a portfolio as the input.
   * @param portfolio is the portfolio the user wants to be dealt with.
   * @param model is the model to deal with the logic in.
   */
  public HandleFile(IPortfolio portfolio, IModel model) {
    this.portfolio = portfolio;
    this.model = model;
    this.quantities = new HashMap<>();
  }

  /**
   * ReadFile parses through a .txt file to extract the necessary data to.
   * store and represent a portfolio.
   * Returns an IPortfolio with the data that was within the file.
   */
  public IPortfolio readFile() {
    LocalDate[] datesInFile = new LocalDate[2];
    List<PurchaseRecord> listOfRecords = new ArrayList<PurchaseRecord>();
    String nameOfPortfolio = "";
    try {
      Scanner scanner = new Scanner(file);
      if (scanner.hasNextLine()) { //logic has it so name is first
        nameOfPortfolio = scanner.nextLine();
      }
      for (int i = 0; i < 2; i++) {
        String dates = scanner.nextLine();
        String[] data = dates.split(",");
        try {
          LocalDate date = LocalDate.parse(data[1].strip());
          datesInFile[i] = date;
        } catch (Exception e) {
          throw new IllegalArgumentException("File not in right format");
        }
      }
      LocalDate creationDate = datesInFile[0];
      LocalDate currentDate = datesInFile[1];
      while (scanner.hasNextLine()) {
        String data = scanner.nextLine();
        String[] splitData = data.split(":");
        String tickerSymbol = splitData[0];
        String[] quantitySplit = splitData[1].split(",");
        for (String quantity : quantitySplit) {
          String[] lastSplit = quantity.split(";");
          double quantityInt = Double.parseDouble(lastSplit[0].strip());
          LocalDate dateOfPurchase = LocalDate.parse(lastSplit[1].strip());
          PurchaseRecord record = new PurchaseRecord(dateOfPurchase, quantityInt);
          listOfRecords.add(record);
        }
        quantities.put(tickerSymbol, listOfRecords);
      }
      if (nameOfPortfolio.isEmpty()) {
        throw new IllegalArgumentException("File could not find name of the portfolio");
      }
      IPortfolio returningPortfolio =
              new AdvancedPortfolio(nameOfPortfolio, creationDate, currentDate);
      for (Map.Entry<String, List<PurchaseRecord>> entry : quantities.entrySet()) {
        for (PurchaseRecord record : entry.getValue()) {
          returningPortfolio.addStock(entry.getKey(), (int) record.getQuantity(),
                  record.getPurchaseDate());
        }
      }
      scanner.close();
      model.addPortfolioWithValues(returningPortfolio);
      return returningPortfolio;
    } catch (FileNotFoundException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
    throw new IllegalArgumentException("File not read properly.");
  }

  /**
   * WriteFile takes in a portfolio that the user wants persisted and saved in their resources.
   * It will put all the necessary data of a portfolio into a .txt file and save it.
   */
  public void writeFile() {
    try {
      FileWriter writer = new FileWriter("resources/" +
              portfolio.getPortfolioName() + ".txt");
      writer.write(portfolio.getPortfolioName() + "\n");
      writer.write("Creation Date," + portfolio.getDateOfCreation() + "\n");
      writer.write("Current Date," + portfolio.getCurrentDate() + "\n");
      for (Map.Entry<String, List<PurchaseRecord>> entry :
              portfolio.getStockHoldings().entrySet()) {
        writer.write(entry.getKey() + ": ");
        for (PurchaseRecord record : entry.getValue()) {
          writer.write(record.getQuantity() + ";" + record.getPurchaseDate() + ",");
        }
        writer.write("\n");
      }
      writer.close();
    } catch (Exception e) {
      throw new IllegalArgumentException("File not written");
    }
  }
}
