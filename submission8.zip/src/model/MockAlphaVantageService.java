package model;

import java.util.HashMap;
import java.util.Map;

/**
 * MockAlphaVantageService is a class to mock request data from an API.
 */
public class MockAlphaVantageService extends AlphaVantageService {
  private Map<String, IStock> stockData = new HashMap<>();

  /**
   * Adds a stockData into a mock of AlphaVantage.
   * @param tickerSymbol is the ticker symbol of the stock to add.
   * @param stock is the actual stock object to use.
   */
  public void addStockData(String tickerSymbol, IStock stock) {
    stockData.put(tickerSymbol, stock);
  }

  @Override
  public IStock fetchStockData(String tickerSymbol) {
    return stockData.get(tickerSymbol);
  }
}
