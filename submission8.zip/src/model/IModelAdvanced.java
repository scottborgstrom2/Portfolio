package model;

import java.time.LocalDate;
import java.util.Map;

/**
 * IModelAdvanced is an extended interface to put the new methods of a new.
 * implementation of model inside. It extends IModel and is utilized by.
 * the new implementation of ModelImpl2. It represents the logic of the program.
 */
public interface IModelAdvanced extends IModel {
  /**
   * This method is to be able to create an advanced portfolio into the model which the.
   * previous model and portfolio was not able to handle.
   * @param portfolioName is the name of the portfolio to save.
   * @param creationDate is when the portfolio was created.
   * @param currentDate is the date the user wants to simulate as "today".
   */
  void addPortfolioAdvanced(String portfolioName, LocalDate creationDate, LocalDate currentDate);

  /**
   * This contains the logic to visualize the performance of a stock or portfolio.
   * This is a visual representation of how a portfolio or stock performs over time.
   * @param name is the of the stock or portfolio to analyze.
   * @param startDate is the starting data of when to start observing the data.
   * @param endDate is the final date to consider of the data observation.
   * @param isPortfolio is a boolean that tells the logic if the name is a stock or portfolio.
   *     Returns a String with a date and astericks to represent the performance over time.
   */
  String visualizePerformance(String name, LocalDate startDate,
                              LocalDate endDate, boolean isPortfolio);

  /**
   * This void method allows the user to input what they want to rebalance the stocks with.
   * It then parses through the values to give the private methods the correct numbers.
   * to properly rebalance the portfolio with PortfolioName.
   * @param portfolioName is the name of the portfolio to rebalance.
   * @param rebalanceDate is when the rebalance is taking place.
   * @param weights is a map of which stock to rebalance and by what measure.
   */
  void rebalancedPortfolio(String portfolioName, LocalDate rebalanceDate,
                           Map<String,Integer> weights);

  /**
   * Counts the number of tickers contained within a portfolio.
   * @param portfolioName is which portfolio to check.
   *     Returns an integer value of how many unique tickerSymbols are within your portfolio.
   */
  int countStock(String portfolioName);
}
