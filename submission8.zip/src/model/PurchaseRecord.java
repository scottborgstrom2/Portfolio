package model;

import java.time.LocalDate;

/**
 * A purchase record is the way to store a successful sale of U.S Stock.
 * It has the date of purchase and how many shares were purchased on that date.
 */
public class PurchaseRecord {
  private LocalDate purchaseDate;
  private double quantity;

  /**
   * Creates an instance of a purchase record.
   * @param purchaseDate is when the stock was purchased.
   * @param quantity is how many shares a user bought.
   */
  public PurchaseRecord(LocalDate purchaseDate, Double quantity) {
    this.purchaseDate = purchaseDate;
    this.quantity = quantity;
  }

  /**
   * Returns the purchase date of a sale.
   */
  protected LocalDate getPurchaseDate() {
    return purchaseDate;
  }

  /**
   * Returns the amount of shares of a sale.
   */
  protected double getQuantity() {
    return quantity;
  }

  /**
   * Adds a new quantity, allowed double so that the user doesn't have access, to a record.
   */
  protected void addQuantity(double quantity) {
    this.quantity += quantity;
  }

  /**
   * Removes a new quantity, allowed double so that the user doesn't have access, to a record.
   */
  protected void removeQuantity(double quantity) {
    this.quantity -= quantity;
  }


}
