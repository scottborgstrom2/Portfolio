package model;

import java.text.NumberFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Portfolio class represents a client buying stocks and holding them in quantities.
 */
public class Portfolio implements IPortfolio {
  Map<String, List<PurchaseRecord>> whatIOwn; // change double to a map
  private final String portfolioName;

  /**
   * Constructor that creates a portfolio object with an empty amount of what you own.
   */
  public Portfolio(String portfolioName) {
    this.whatIOwn = new HashMap<>();
    this.portfolioName = portfolioName;
  }

  @Override
  public String getPortfolioName() {
    return portfolioName;
  }

  @Override
  public void addStock(String tickerSymbol, int quantity, LocalDate dateOfPurchase) {
    if (quantity <= 0) {
      throw new IllegalArgumentException("Quantity must be greater than 0");
      // if an exception is thrown, try catch it and handle that logic elsewhere
    }
    PurchaseRecord updatedRecord = new PurchaseRecord(dateOfPurchase, (double) quantity);
    List<PurchaseRecord> records = whatIOwn.get(tickerSymbol);
    if (records == null) {
      records = new ArrayList<>();
    }
    records.add(updatedRecord);
    this.whatIOwn.put(tickerSymbol, records);
  }

  @Override
  public void removeStock(String tickerSymbol, int quantity, LocalDate dateOfSale) {
    if (!this.whatIOwn.containsKey(tickerSymbol) || quantity <= 0) {
      throw new IllegalArgumentException("Ticker symbol in this portfolio " +
              "doesn't exist or quantity is invalid");
    }
    double currentQuantity = getTotalQuantity(tickerSymbol, dateOfSale);
    if (quantity > currentQuantity) {
      throw new IllegalArgumentException("Attempting to remove more than you own");
    }
    if (quantity == currentQuantity) {
      this.whatIOwn.remove(tickerSymbol);
    } else {
      for (PurchaseRecord record : this.whatIOwn.get(tickerSymbol)) {
        while (quantity > 0) {
          if ((record.getPurchaseDate().isBefore(dateOfSale) ||
                  record.getPurchaseDate().equals(dateOfSale))) {
            if (record.getQuantity() <= quantity) {
              this.whatIOwn.get(tickerSymbol).remove(record);
              quantity -= (int) record.getQuantity();
            } else {
              record.removeQuantity(quantity);
              quantity = 0;
            }
          }
        }
      }
    }
  }

  protected double getTotalQuantity(String tickerSymbol, LocalDate date) {
    double currentQuantity = 0.0;
    for (PurchaseRecord record : this.whatIOwn.get(tickerSymbol)) {
      if (record.getPurchaseDate().isBefore(date)
              || record.getPurchaseDate().equals(date)) {
        currentQuantity += record.getQuantity();
      }
    }
    if (currentQuantity == 0.0) {
      throw new IllegalArgumentException("Cannot find any records for " + tickerSymbol);
    }
    return currentQuantity;
  }

  @Override
  public double getPortfolioValue(LocalDate date, IModel model) {
    double totalValue = 0.0;
    for (Map.Entry<String, List<PurchaseRecord>> entry : this.whatIOwn.entrySet()) {
      String tickerSymbol = entry.getKey();
      double quantity = getTotalQuantity(tickerSymbol, date);
      IStock stock = model.getStock(tickerSymbol);
      if (stock == null) {
        throw new IllegalArgumentException("Stock symbol " + tickerSymbol + " not found");
      }
      double price = stock.getPrice(date);
      // loop until you get the nearest closing price.
      while (price == 0.0) {
        date = date.minusDays(1);
        price = stock.getPrice(date);
      }
      totalValue += price * quantity;
    }
    return totalValue;
  }


  @Override
  public String distributionOfPortfolio(LocalDate date, IModel model) {
    boolean marketClosed = false;
    StringBuilder result = new StringBuilder();
    NumberFormat formatter = NumberFormat.getCurrencyInstance();
    result.append("Finding distribution of portfolio on " + date.toString() + ": \n");
    for (Map.Entry<String, List<PurchaseRecord>> entry : whatIOwn.entrySet()) {
      String tickerSymbol = entry.getKey();
      IStock stock = model.getStock(tickerSymbol);
      double price = stock.getPrice(date);
      while (price == 0.0) {
        marketClosed = true;
        date = date.minusDays(1);
        price = stock.getPrice(date);
      }
      double quantity = getTotalQuantity(tickerSymbol, date);
      double value = price * quantity;
      result.append("The stock: " + tickerSymbol + " is worth: " + formatter.format(value) + "\n");
    }
    if (marketClosed) {
      result.append("On the selected date, market is closed. Finding most recent " +
              "stock data on: " + date + "\n");
    }
    result.append("The value of the portfolio today is: " +
            formatter.format(this.getPortfolioValue(date, model)));
    return result.toString();
  }


  @Override
  public double getStockQuantity(String tickerSymbol) {
    return getTotalQuantity(tickerSymbol, LocalDate.now());
  }

  @Override
  public Map<String, List<PurchaseRecord>> getStockHoldings() {
    return new HashMap<>(whatIOwn);
  }

  //returns null and is handled properly down the line
  @Override
  public LocalDate getDateOfCreation() {
    return null;
  }

  //returns null and is handled properly down the line
  @Override
  public LocalDate getCurrentDate() {
    return null;
  }

  @Override
  public void shiftThisStock(double numShares, String ticker, LocalDate date) {
    //shift this stock does nothing in this class, due to limitations with interface expansion.
    //addressed in the Design.readME
    numShares = 0.0;
  }

  @Override
  public String getPortfolioSummary() {
    StringBuilder result = new StringBuilder();
    for (Map.Entry<String, List<PurchaseRecord>> entry : this.whatIOwn.entrySet()) {
      result.append("The stock ").append(entry.getKey()).append(" has this many shares: ")
              .append(getTotalQuantity(entry.getKey(), LocalDate.now())).append("\n");
    }
    return result.toString();
  }


  // for data visualization
  @Override
  public Map<LocalDate, Double> getPortfolioValues(LocalDate startDate,
                                                   LocalDate endDate, IModel model) {
    Map<LocalDate, Double> portfolioValues = new HashMap<>();
    LocalDate currentDate = startDate;

    while (!currentDate.isAfter(endDate)) {
      try {
        double value = getPortfolioValue(currentDate, model);
        portfolioValues.put(currentDate, value);
      } catch (IllegalArgumentException e) {
        //empty body in order to catch the exceptions that weekends produce.
      }
      currentDate = currentDate.plusDays(1);
    }

    return portfolioValues;
  }
}