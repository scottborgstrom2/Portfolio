package model;

import java.time.LocalDate;
import java.util.ArrayList;

import java.util.List;
import java.util.Map;

/**
 * An advanced portfolio extends the functionality of a regular portfolio.
 * The new features include the portfolio's creation date stored as a field.
 * Also, the "current" date that the portfolio wants to be viewed at.
 */
public class AdvancedPortfolio extends Portfolio {
  private final LocalDate dateOfCreation;
  private LocalDate currentDate;

  /**
   * Constructor that creates a portfolio object with an empty amount of what you own.
   * Takes in the date of creation as well.
   *
   * @param portfolioName is the identifier of this portfolio.
   */
  public AdvancedPortfolio(String portfolioName, LocalDate dateOfCreation, LocalDate currentDate) {
    super(portfolioName);
    this.dateOfCreation = dateOfCreation;
    this.currentDate = currentDate;
  }

  @Override
  public double getPortfolioValue(LocalDate date, IModel model) {
    if (this.dateOfCreation.isAfter(date)) {
      return 0.0;
    }
    return super.getPortfolioValue(date, model);
  }

  @Override
  public String distributionOfPortfolio(LocalDate date, IModel model) {
    if (date.isBefore(this.dateOfCreation)) {
      return "Distribution not found. Date is before date of creation";
    } else {
      return super.distributionOfPortfolio(date, model);
    }
  }

  /**
   * Returns the date of creation as a Date.
   */
  public LocalDate getDateOfCreation() {
    return this.dateOfCreation;
  }

  /**
   * Returns the "current" date as a Date.
   * Current meaning a simulation based current of when the user wants.
   */
  public LocalDate getCurrentDate() {
    return this.currentDate;
  }

  @Override
  public String getPortfolioSummary() {
    StringBuilder result = new StringBuilder();
    for (Map.Entry<String, List<PurchaseRecord>> entry : getStockHoldings().entrySet()) {
      result.append("The stock ").append(entry.getKey()).append(" has this many shares: ")
              .append(getTotalQuantity(entry.getKey(), currentDate)).append("\n");
    }
    return result.toString();
  }

  @Override
  public double getStockQuantity(String tickerSymbol) {
    return getTotalQuantity(tickerSymbol, currentDate);
  }


  @Override
  public void shiftThisStock(double numShares, String ticker, LocalDate date) {
    double sharesCurrently = this.getTotalQuantity(ticker, date);
    if (numShares > sharesCurrently) {
      double sum = numShares - sharesCurrently;
      this.buyFractional(ticker, sum, date);
      //sell the difference
    }
    if (numShares < sharesCurrently) {
      double difference = sharesCurrently - numShares;
      this.sellFractional(ticker, difference, date);
    }
  }

  /**
   * This private method makes sure that users cannot buy fractional shares.
   * However, allows the program to properly adjust shares if there is a split.
   * or a rebalancing that requires the representation of shares as a double.
   * @param ticker is the ticker symbol of the stock shares.
   * @param share is how many shares to buy.
   * @param date is when to buy the shares.
   */
  private void buyFractional(String ticker, double share, LocalDate date) {
    PurchaseRecord newPurchase = new PurchaseRecord(date, share);
    List<PurchaseRecord> records = whatIOwn.get(ticker);
    if (records == null) {
      records = new ArrayList<>();
    }
    records.add(newPurchase);
    this.whatIOwn.put(ticker, records);
  }

  /**
   * This private method makes sure that users cannot sell fractional shares.
   * However, allows the program to properly adjust shares if there is a split.
   * or a rebalancing that requires the representation of shares as a double.
   * @param ticker is the ticker symbol of the stock shares.
   * @param share is how many shares to sell.
   * @param date is when to sell the shares.
   */
  private void sellFractional(String ticker, double share, LocalDate date) {
    double currentQuantity = getTotalQuantity(ticker, date);
    if (share == currentQuantity) {
      this.whatIOwn.remove(ticker);
    } else {
      for (PurchaseRecord record : this.whatIOwn.get(ticker)) {
        while (share > 0.0) {
          if ((record.getPurchaseDate().isBefore(date) ||
                  record.getPurchaseDate().equals(date))) {
            if (record.getQuantity() <= share) {
              this.whatIOwn.get(ticker).remove(record);
              share -= record.getQuantity();
            } else {
              record.removeQuantity(share);
              share = 0.0;
            }
          }
        }
      }
    }
  }
}

