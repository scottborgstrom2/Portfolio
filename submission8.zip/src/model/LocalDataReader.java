package model;

import java.io.BufferedReader;
import java.io.FileReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * LocalDataReader reads stock data from a local CSV file.
 */
public class LocalDataReader {
  private final String FILE_PATH = "resources/GOOG-csvfile.csv"; // Adjust the path as needed
  private final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd");

  /**
   * Fetches the stock data at a ticker symbol.
   *
   * @param tickerSymbol is the ticker to look for locally.
   */
  public static IStock fetchStockData(String tickerSymbol) {
    IStock stock = new Stock(tickerSymbol);
    Map<LocalDate, Double> priceData = new HashMap<>();

    try {
      BufferedReader br = new BufferedReader(new FileReader("resources/" + tickerSymbol
              + "-csvfile.csv"));
      String line;
      br.readLine();
      while ((line = br.readLine()) != null) {
        if (line.contains("Error Message")) {
          throw new IllegalArgumentException("Error Message in fetching locally");
        }
        String[] values = line.split(",");
        LocalDate date = LocalDate.parse(values[0]);
        ArrayList<Double> data = new ArrayList<>();
        double closingPrice = Double.parseDouble(values[4]);
        stock.addPrice(date, closingPrice);
      }
    } catch (Exception e) {
      throw new IllegalStateException("Error reading local stock data");
    }
    return stock;
  }
}
