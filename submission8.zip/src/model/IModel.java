package model;

import java.time.LocalDate;
import java.util.List;

/**
 * IModel represents the interface where the logic of the program is conducted.
 */
public interface IModel {
  /**
   * This method grabs data from the API to retrieve the stock listed.
   * under the ticker and adds it to our local fields.
   *
   * @param tickerSymbol is the identifier for what stock to find.
   */
  void fetchAndAddStock(String tickerSymbol);


  /**
   * Calculates the gain or loss of a stock from a start date to end date.
   *
   * @param tickerSymbol is what stock to evaluate.
   * @param startDate    is the starting date to consider.
   * @param endDate      is the end date to consider for this calculation.
   */
  double calculateGainLoss(String tickerSymbol, LocalDate startDate, LocalDate endDate);

  /**
   * This calculates the average over a user inputted amount of days for a specific stock.
   *
   * @param tickerSymbol is the stock to analyze.
   * @param date         is the first date to consider.
   * @param days         is how many days after the first date to look at the moving average.
   *                     Returns a double that is the moving average.
   */
  double calculateMovingAverage(String tickerSymbol, LocalDate date, int days);

  /**
   * This calculates the average over a user inputted amount of days for a specific stock.
   *
   * @param tickerSymbol is the stock to analyze.
   * @param startDate    is the first date to consider.
   * @param endDate      is the last date to for the range of datews.
   * @param x            is how many days to calculate the moving average with
   *                     Returns a list of the localdates that have a closing value
   *                     above the crossover value.
   */
  List<LocalDate> calculateCrossover(String tickerSymbol, LocalDate startDate,
                                     LocalDate endDate, int x);

  /**
   * Returns the stock held in Stocks under the tickerSymbol.
   *
   * @param tickerSymbol is the ticker symbol to check
   */
  IStock getStock(String tickerSymbol);

  /**
   * Adds a portfolio to the models HashMap to store multiple portfolios as a static.
   */
  public void addPortfolio(String portfolioName);

  /**
   * Returns a portfolio that is stored in the map if it exists with the name.
   *
   * @param portfolioName is the identifier of the instances of portfolios.
   */
  public IPortfolio getPortfolio(String portfolioName);

  /**
   * This adds a portfolio that contains values, (has data) into the portfolios.
   * that the model recognizes as valid data points.
   * @param portfolio is the portfolio to locally store.
   */
  public void addPortfolioWithValues(IPortfolio portfolio);


}