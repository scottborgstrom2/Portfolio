package model;


import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

/**
 * Stock class represents a stock available for purchase on the stock market.
 * A stock has a ticker and a price history.
 */
public class Stock implements IStock {
  private final String tickerSymbol;
  private final Map<LocalDate, Double> priceHistory;

  /**
   * Creates a Code object of type Stock that has a ticker.
   * and a price history to store data about the stock.
   *
   * @param tickerSymbol is the identifier, the stock ticker name.
   */
  public Stock(String tickerSymbol) {
    if (tickerSymbol == null) {
      throw new IllegalArgumentException("Ticker symbol cannot be null");
    }
    this.tickerSymbol = tickerSymbol;
    this.priceHistory = new HashMap<>();
  }

  //returns the tickerSymbol
  @Override
  public String getTickerSymbol() {
    return tickerSymbol;
  }

  //adds the price to the history in a hashMap
  @Override
  public void addPrice(LocalDate date, double price) {
    priceHistory.put(date, price);
  }

  //returns the price and if not found, returns 0 to be dealt with later
  @Override
  public Double getPrice(LocalDate date) {
    return priceHistory.getOrDefault(date, 0.0);
  }


  // new for data visualization
  @Override
  public Map<LocalDate, Double> getPerformanceData(LocalDate startDate, LocalDate endDate) {
    Map<LocalDate, Double> performanceData = new HashMap<>();
    LocalDate currentDate = startDate;
    while (!currentDate.isAfter(endDate)) {
      double price = getPrice(currentDate);
      if (price != 0.0) {
        performanceData.put(currentDate, price);
      }
      currentDate = currentDate.plusDays(1);
    }
    if (performanceData.isEmpty()) {
      throw new IllegalArgumentException("No data found between these dates");
    }
    return performanceData;
  }

}


