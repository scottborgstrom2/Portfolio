package model;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/**
 * This interface represents a portfolio where a user can manage what quantities of stock.
 * to purchase and maintain.
 */
public interface IPortfolio {
  /**
   * Adds a stock of the tickerSymbol to the portfolio with the given quantity.
   *
   * @param tickerSymbol the ticker symbol of the stock
   * @param quantity     the quantity of the stock to add
   */
  void addStock(String tickerSymbol, int quantity, LocalDate dateOfPurchase);

  /**
   * Removes a stock from the portfolio of the name TickerSymbol.
   *
   * @param tickerSymbol is the ticker symbol of the stock to remove.
   * @param quantity     is the amount of stock to remove from the portfolio.
   */
  void removeStock(String tickerSymbol, int quantity, LocalDate dateOfSale);


  /**
   * Gets the total value of the portfolio on the given date.
   *
   * @param date  the date that you want the calculation of the portfolio.
   * @param model the model to fetch the data with.
   * @return the total value of the portfolio
   */
  double getPortfolioValue(LocalDate date, IModel model);


  /**
   * Gets the quantity of a specific stock in the portfolio.
   * if stock doesn't exist in the portfolio, informs the user.
   *
   * @param tickerSymbol the ticker symbol of the stock
   * @return the quantity of the stock if it exists.
   */
  double getStockQuantity(String tickerSymbol);

  /**
   * Returns a summary of the portfolio with all stocks and their quantities.
   * Does not allow user direct access to the portfolio, however.
   *
   * @return a String breakdown of the portfolio.
   */
  String getPortfolioSummary();

  /**
   * Returns the name of a portfolio used to identify the different portfolios.
   */
  String getPortfolioName();

  /**
   * Returns the value of a portfolio on every date in between a range of dates.
   * @param startDate is when to start your range of dates, inclusive.
   * @param endDate is when to end your range of dates, inclusive.
   * @param model is the model in which the logic is handled.
   *     Returns a map of dates as keys with their values being the closing price
   *              values of the port.
   */
  Map<LocalDate, Double> getPortfolioValues(LocalDate startDate, LocalDate endDate, IModel model);

  /**
   * Returns a detailed interpretation of what is contained within a portfolio on a given date.
   * The stocks, their tickers, their quantities, and value.
   * @param date is when to check the distribution.
   * @param model is the model that handles the logic.
   */
  String distributionOfPortfolio(LocalDate date, IModel model);

  /**
   * Returns a deep copy of the Map of stock holdings, represents a ticker and.
   * the history of its purchasing.
   */
  public Map<String, List<PurchaseRecord>> getStockHoldings();

  /**
   * Returns the creation date of a portfolio.
   */
  LocalDate getDateOfCreation();

  /**
   * Returns the "current" date of a portfolio.
   * Current meaning the day the user choose as "today".
   */
  LocalDate getCurrentDate();

  /**
   * Shift this stock handles the rebalancing by letting the program know.
   * how the individual stocks in a portfolio should be rebalanced, fractionally.
   * @param numShares is how many shares the desired rebalance is.
   * @param ticker is the tickerSymbol of the stock to rebalance.
   * @param date is when the rebalancing is happening.
   */
  void shiftThisStock(double numShares, String ticker, LocalDate date);

}
