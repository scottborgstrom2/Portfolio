package model;

import java.time.LocalDate;
import java.util.ArrayList;

import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * ModelImpl2 is a second implementation of model that extends the first implementation.
 * and utilizes a new interface to include new functionality.
 * ModelImpl still handles all the logic to communicate with the controller.
 */
public class ModelImpl2 extends ModelImpl implements IModelAdvanced {
  protected LocalDate creationDate;
  protected LocalDate currentDate;

  /**
   * Creates an object of ModelImpl2 that takes in the creation and current date.
   * to aid with the new advanced portfolio implementation.
   *
   * @param creationDate is the date of creation for a certain portfolio.
   * @param currentDate  is the current date for a certain portfolio.
   */
  public ModelImpl2(LocalDate creationDate, LocalDate currentDate) {
    this.creationDate = creationDate;
    this.currentDate = currentDate;
  }

  /**
   * Creates a convenience constructor object for ModelImpl2.
   */
  public ModelImpl2() {
    //empty body
  }

  @Override
  public void addPortfolioAdvanced(String portfolioName, LocalDate creationDate,
                                   LocalDate currentDate) {
    // added in a check for null or empty portfolio name
    if (portfolioName == null || portfolioName.isEmpty()) {
      throw new IllegalArgumentException("Portfolio name cannot be null or empty");
    }
    if (!portfolios.containsKey(portfolioName)) {
      if (creationDate == null || currentDate == null) {
        throw new IllegalArgumentException("Creation or current date is null");
      }
      portfolios.put(portfolioName,
              new AdvancedPortfolio(portfolioName, creationDate, currentDate));
    } else {
      throw new IllegalArgumentException("Portfolio already exists");
    }
  }


  // new for data visualization
  @Override
  public String visualizePerformance(String name, LocalDate startDate,
                                     LocalDate endDate, boolean isPortfolio) {
    Map<LocalDate, Double> performanceData =
            getPerformanceData(name, startDate, endDate, isPortfolio);

    if (performanceData.isEmpty()) {
      throw new IllegalArgumentException("No performance data " +
              "available for the specified period.");
    }

    String timeFrame = determineTimeFrame(startDate, endDate);
    Map<LocalDate, Double> filteredData = filterDataByTime(startDate, endDate,
            performanceData, timeFrame);

    double scale = determineScale(filteredData);

    return generateBarChart(name, startDate, endDate, filteredData, scale);
  }

  /**
   * Returns the performance of a portfolio or stock based on the boolean flag, isPortfolio.
   * The performance meaning the values of the prices on specific dates.
   *
   * @param name        is the name of the stock or portfolio.
   * @param startDate   is the first date to consider in a range of dates.
   * @param endDate     is the final date to consider.
   * @param isPortfolio is a boolean flag letting us know if it is a stock or portfolio.
   */
  private Map<LocalDate, Double> getPerformanceData(String name, LocalDate startDate,
                                                    LocalDate endDate, boolean isPortfolio) {
    if (isPortfolio) {
      IPortfolio portfolio = getPortfolio(name);
      return portfolio.getPortfolioValues(startDate, endDate, this);
    } else {
      IStock stock = getStock(name);
      if (stock == null) {
        throw new IllegalArgumentException("Stock " + name + " not found");
      }
      return stock.getPerformanceData(startDate, endDate);
    }
  }

  /**
   * This aids in the logic of determining the scale of the visualization asteriks.
   * Making sure that the scale is logical based on the maximum value in the performance.
   * Returns a double to use for the scale in data visualization.
   *
   * @param performanceData is the map of data of prices in a portfolio/stock.
   */
  private double determineScale(Map<LocalDate, Double> performanceData) {
    double maxValue = 0.0;
    for (double value : performanceData.values()) {
      if (value > maxValue) {
        maxValue = value;
      }
    }

    if (maxValue / 50 <= 1) {
      return 1;
    } else if (maxValue / 50 <= 10) {
      return 10;
    } else if (maxValue / 50 <= 50) {
      return 50;
    } else if (maxValue / 50 <= 100) {
      return 100;
    } else {
      return 1000;
    }
  }

  /**
   * This determines the time frame between two dates.
   * Returns a String based on how many days are between the dates.
   *
   * @param startDate is the first date to consider in the time frame.
   * @param endDate   is the final date to consider, inclusive.
   */
  private String determineTimeFrame(LocalDate startDate, LocalDate endDate) {
    int daysBetween = 0;
    LocalDate date = startDate;
    while (!date.isAfter(endDate)) {
      daysBetween++;
      date = date.plusDays(1);
    }

    if (daysBetween < 5) {
      throw new IllegalArgumentException("Not enough data to properly visualize.");
    } else if (daysBetween > 5 && daysBetween <= 30) {
      return "days";
    } else if (daysBetween > 30 && daysBetween <= 150) {
      return "weeks";
    } else if (daysBetween > 150 && daysBetween <= 457) {
      return "months";
    } else if (daysBetween > 457 && daysBetween <= 1825) {
      return "quarters";
    } else {
      return "years";
    }
  }


  /**
   * This finds the last day that was capable of trading.
   *
   * @param date            is the date to start at,
   *                        subtracting until the performance data doesn't have.
   * @param performanceData is the Map of data to consider.
   *                        Returns a LocalDate of the last day inside of the data.
   */
  private LocalDate getLastTradingDay(LocalDate date, Map<LocalDate, Double> performanceData) {
    LocalDate forwardDate = date;
    // Try moving forward first
    while (!performanceData.containsKey(forwardDate) && !forwardDate.isAfter(date.plusDays(7))) {
      forwardDate = forwardDate.plusDays(1);
    }
    // If no valid forward date within a week, move backward
    while (!performanceData.containsKey(date)) {
      date = date.minusDays(1);
    }
    if (performanceData.containsKey(forwardDate)) {
      return forwardDate;
    } else {
      return date;
    }
  }


  /**
   * This method filters the data based on time, goes through the time frame and decides
   * if the data should be represented as days, weeks, months, quarters, or years.
   * Aids in the logic of representing data visually.
   *
   * @param startDate       is the first date in the time frame to consider, inclusive.
   * @param endDate         is the last date in the time frame to consider, inclusive.
   * @param performanceData is the Map of data of prices within that time frame.
   * @param timeFrame       is the determined "days, weeks, months, quarters..."
   *                        to help the switch case.
   */
  private Map<LocalDate, Double> filterDataByTime(LocalDate startDate, LocalDate endDate,
                                                  Map<LocalDate, Double> performanceData,
                                                  String timeFrame) {
    Map<LocalDate, Double> filteredDatesForRow = new TreeMap<>();
    LocalDate currentDate = startDate;

    switch (timeFrame) {
      case "days":
        while (!currentDate.isAfter(endDate)) {
          LocalDate tradingDay = getLastTradingDay(currentDate, performanceData);
          filteredDatesForRow.put(tradingDay, performanceData.getOrDefault(tradingDay, 0.0));
          currentDate = currentDate.plusDays(1);
        }
        break;
      case "weeks":
        while (!currentDate.isAfter(endDate)) {
          currentDate = getLastTradingDay(currentDate, performanceData);
          filteredDatesForRow.put(currentDate, performanceData.getOrDefault(currentDate, 0.0));

          LocalDate potentialWeekEnd = currentDate.plusDays(6);
          LocalDate weekEnd = getLastTradingDay(potentialWeekEnd, performanceData);
          if (weekEnd.isAfter(endDate)) {
            weekEnd = endDate;
          }
          filteredDatesForRow.put(weekEnd, performanceData.getOrDefault(weekEnd, 0.0));

          currentDate = currentDate.plusWeeks(1);
        }
        break;
      case "months":
        while (!currentDate.isAfter(endDate)) {
          currentDate = getLastTradingDay(currentDate, performanceData);
          filteredDatesForRow.put(currentDate, performanceData.getOrDefault(currentDate, 0.0));

          LocalDate potentialMonthEnd = currentDate.plusMonths(1).minusDays(1);
          LocalDate monthEnd = potentialMonthEnd;
          if (monthEnd.isAfter(endDate)) {
            monthEnd = endDate;
          }
          monthEnd = getLastTradingDay(monthEnd, performanceData);
          filteredDatesForRow.put(monthEnd, performanceData.getOrDefault(monthEnd, 0.0));

          currentDate = currentDate.plusMonths(1);
        }
        break;
      case "quarters":
        while (!currentDate.isAfter(endDate)) {
          currentDate = getLastTradingDay(currentDate, performanceData);
          filteredDatesForRow.put(currentDate, performanceData.getOrDefault(currentDate, 0.0));

          LocalDate potentialQuarterEnd = currentDate.plusMonths(3).minusDays(1);
          LocalDate quarterEnd = potentialQuarterEnd;
          if (quarterEnd.isAfter(endDate)) {
            quarterEnd = endDate;
          }
          quarterEnd = getLastTradingDay(quarterEnd, performanceData);
          filteredDatesForRow.put(quarterEnd, performanceData.getOrDefault(quarterEnd, 0.0));

          currentDate = currentDate.plusMonths(3);
        }
        break;
      case "years":
        while (!currentDate.isAfter(endDate)) {
          currentDate = getLastTradingDay(currentDate, performanceData);
          filteredDatesForRow.put(currentDate, performanceData.getOrDefault(currentDate, 0.0));

          LocalDate potentialYearEnd = currentDate.plusYears(1).minusDays(1);
          LocalDate yearEnd = potentialYearEnd;
          if (yearEnd.isAfter(endDate)) {
            yearEnd = endDate;
          }
          yearEnd = getLastTradingDay(yearEnd, performanceData);
          filteredDatesForRow.put(yearEnd, performanceData.getOrDefault(yearEnd, 0.0));

          currentDate = currentDate.plusYears(1);
        }
        break;
      default:
        throw new IllegalArgumentException("Invalid time frame: " + timeFrame);
    }

    return filteredDatesForRow;
  }






  /**
   * Generates the actual bar chart, representing a visual aid in the performance of a stock.
   * or portfolio over time using astericks that represents a scaled amount of dollars.
   *
   * @param name            is the name of the bar chart for the user.
   * @param startDate       is the first date in the time frame to consider, inclusive.
   * @param endDate         is the last date in the time frame to consider, inclusive.
   * @param performanceData is the Map of data of prices within that time frame.
   * @param scale           is the scale to represent in the legend to tell the user
   *                        what the astericks are.
   *                        Returns a String that is the actual bar chart.
   */
  private String generateBarChart(String name, LocalDate startDate,
                                  LocalDate endDate, Map<LocalDate, Double> performanceData,
                                  double scale) {
    StringBuilder chart = new StringBuilder();
    chart.append(String.format("Performance of %s from %s to %s\n\n", name, startDate, endDate));

    for (Map.Entry<LocalDate, Double> entry : performanceData.entrySet()) {
      LocalDate date = entry.getKey();
      double value = entry.getValue();
      int asterisks = (int) (value / scale);
      if (asterisks > 50) {
        asterisks = 50;
      }
      chart.append(String.format("%s: %s\n", date, "*".repeat(asterisks)));
    }

    chart.append(String.format("\nScale: * = %.2f\n", scale));

    return chart.toString();
  }

  @Override
  public void rebalancedPortfolio(String portfolioName, LocalDate rebalanceDate,
                                  Map<String, Integer> weights) {
    // Check if name is null or if it is empty
    if (portfolioName == null || portfolioName.isEmpty()) {
      throw new IllegalArgumentException("Portfolio name cannot be null or empty");
    }

    IPortfolio portfolio = getPortfolio(portfolioName);
    double totalValueOfPortfolio = portfolio.getPortfolioValue(rebalanceDate, this);

    for (Map.Entry<String, Integer> entry : weights.entrySet()) {
      // Get the stock symbol for each stock
      String stockSymbol = entry.getKey();
      // Get the weight
      double weight = (double) entry.getValue() / 100;
      double intendedValueOfStock = weight * totalValueOfPortfolio;
      IStock stock = this.getStock(stockSymbol);
      double price = stock.getPrice(rebalanceDate);
      double intendedShares = intendedValueOfStock / price;
      portfolio.shiftThisStock(intendedShares, stockSymbol, rebalanceDate);
    }
  }



  @Override
  public int countStock(String portfolioName) {
    try {
      IPortfolio portfolio = portfolios.get(portfolioName);
      Map<String, List<PurchaseRecord>> portfolioInfo = portfolio.getStockHoldings();
      List<String> namesOfStocks = new ArrayList<>();
      for (Map.Entry<String, List<PurchaseRecord>> entry : portfolioInfo.entrySet()) {
        String key = entry.getKey();
        if (!namesOfStocks.contains(key)) {
          namesOfStocks.add(key);
        }
      }
      return namesOfStocks.size();
    } catch (Exception e) {
      throw new IllegalArgumentException("Cannot find portfolio to count stock in");
    }
  }
}