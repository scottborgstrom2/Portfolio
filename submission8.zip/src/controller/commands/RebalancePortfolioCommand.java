package controller.commands;

import model.IModelAdvanced;
import model.IPortfolio;
import view.IView;

import java.io.IOException;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 * This class represents the command to rebalance a portfolio.
 */
public class RebalancePortfolioCommand extends AbstractCommand {

  public RebalancePortfolioCommand() {
    // empty body to allow creation.
  }

  @Override
  public void run(IModelAdvanced model, Scanner scanner, IView view) throws IOException {
    view.displayMessage("Enter the name of the portfolio you want to rebalance: ");
    String nameOfPortfolio = scanner.next();

    IPortfolio portfolio;
    try {
      portfolio = model.getPortfolio(nameOfPortfolio);
    } catch (Exception e) {
      view.displayMessage("Portfolio not found.");
      return;
    }

    view.displayMessage("Here is a list of all stock in that portfolio:");
    view.displayMessage(portfolio.getPortfolioSummary());

    int amountOfTickers = model.countStock(nameOfPortfolio);
    Map<String, Integer> stockWeights = new HashMap<>();

    for (int i = 0; i < amountOfTickers; i++) {
      view.displayMessage("Which stock would you like to assign a weight to? ");
      String nameOfStock = scanner.next();
      view.displayMessage("What is the weight you would like to assign to that stock? " +
              "Please ensure that you enter a value 1-100 and the total of the weights" +
              "has to equal to 100. ");
      int weightOfStock = scanner.nextInt();
      if (weightOfStock < 1 || weightOfStock > 100) {
        view.displayMessage("Invalid weight. Please enter a value between 1 and 100.");
        return;
      }
      stockWeights.put(nameOfStock, weightOfStock);
    }
    int totalWeight = 0;
    for (Map.Entry<String, Integer> entry : stockWeights.entrySet()) {
      totalWeight += entry.getValue();
    }
    if (totalWeight != 100) {
      view.displayMessage("The weights did not sum to 100. Please try again.");
      return;
    }

    view.displayMessage("What date would you like to rebalance your portfolio on?");
    LocalDate rebalanceDate = LocalDate.parse(scanner.next());
    try {
      model.rebalancedPortfolio(nameOfPortfolio, rebalanceDate, stockWeights);
      portfolio = model.getPortfolio(nameOfPortfolio);
      view.displayMessage("Your portfolio " + nameOfPortfolio + " has been rebalanced.");
      view.displayMessage("The new value of this portfolio is $" +
              portfolio.getPortfolioValue(rebalanceDate, model));
      view.displayMessage("Your updated portfolio now contains: \n"
              + portfolio.getPortfolioSummary());
    } catch (IllegalArgumentException e) {
      view.displayMessage(e.getMessage());
    }
  }
}
