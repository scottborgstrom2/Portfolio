package controller.commands;

import model.IModelAdvanced;
import view.IView;

import java.io.IOException;
import java.util.Scanner;

/**
 * This is a class that represents the command of a moving average function.
 * It executes an out print to the user to obtain inputs.
 * Then shows the user the proper moving average.
 */

public class MovingAverageCommand extends AbstractCommand {

  /**
   * Constructor that takes in the fields from super.
   */
  public MovingAverageCommand() {
    super();
  }

  @Override
  public void run(IModelAdvanced model, Scanner scanner, IView view) throws IOException {
    super.run(model, scanner, view);
    view.displayMessage("Enter amount of days as an integer: ");
    int daysOfMovingAverage = scanner.nextInt();

    // to calculate
    double movingAverage = model.calculateMovingAverage(tickerSymbol, startDate,
            daysOfMovingAverage);
    view.displayMessage("Moving Average: $" + movingAverage);
  }
}
