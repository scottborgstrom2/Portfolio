package controller.commands;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Scanner;

import model.IModelAdvanced;
import model.IStock;
import model.Stock;
import view.IView;

/**
 * Abstract command is a class that abstracts common code for all commands.
 */
public abstract class AbstractCommand implements ICommand {
  protected IStock stock;
  protected String tickerSymbol;
  protected LocalDate startDate;

  /**
   * Convenience constructor.
   */
  public AbstractCommand() {
    //empty body, nothing should be initialized.
  }

  /**
   * Run executes the code for the command.
   * @param model is the model used.
   * @param scanner is the scanner given for inputs.
   * @param view is the view to display.
   *     throws an IOException if handled improperly.
   */
  public void run(IModelAdvanced model, Scanner scanner, IView view) throws IOException {
    view.displayMessage("Enter ticker symbol: ");
    tickerSymbol = scanner.next();
    while (true) {
      try {
        stock = new Stock(tickerSymbol);
        break;
      } catch (IllegalArgumentException e) {
        view.displayMessage("Ticker not found. Enter ticker symbol: ");
        tickerSymbol = scanner.next();
      }
    }
    view.displayMessage("Enter start date (YYYY-MM-DD): ");
    String startDateStr = scanner.next();
    startDate = LocalDate.parse(startDateStr);

    model.fetchAndAddStock(tickerSymbol);

    while (model.getStock(tickerSymbol).getPrice(startDate) == 0) {
      view.displayMessage("Stock data isn't available; try again");
      view.displayMessage("Enter start date (YYYY-MM-DD): ");
      startDateStr = scanner.next();
      startDate = LocalDate.parse(startDateStr);
    }
  }

}
