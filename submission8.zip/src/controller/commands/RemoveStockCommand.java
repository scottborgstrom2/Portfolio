package controller.commands;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Scanner;

import model.IModelAdvanced;
import model.IPortfolio;
import view.IView;

/**
 * The remove stock command takes away shares of a stock inside a requested portfolio.
 * This represents the selling of a stock in the US market.
 */
public class RemoveStockCommand extends AbstractCommand {

  /**
   * Constructor to build the command.
   */
  public RemoveStockCommand() {
    //empty body to allow for a call.
  }

  @Override
  public void run(IModelAdvanced model, Scanner scanner, IView view) throws IOException {
    while (true) {
      view.displayMessage("Which portfolio do you want to remove from: ");
      String portfolioName = scanner.next();
      IPortfolio portfolio;
      try {
        portfolio = model.getPortfolio(portfolioName);
        view.displayMessage("Portfolio " + portfolioName + " selected.");
      } catch (IllegalArgumentException e) {
        view.displayMessage("This portfolio does not exist. Please create a portfolio" +
                " by returning to the menu and creating one.");
        break;
      }
      view.displayMessage("Enter ticker symbol: ");
      String tickerSymbol = scanner.next();
      try  {
        model.fetchAndAddStock(tickerSymbol);
        view.displayMessage("Ticker symbol " + tickerSymbol + " selected.");
      } catch (Exception e) {
        view.displayMessage("Invalid ticker symbol. Please try again.");
      }
      view.displayMessage("Enter quantity you'd like to sell: ");
      int quantity = scanner.nextInt();
      // Get the start date from the user
      view.displayMessage("Enter date of sale (YYYY-MM-DD): ");
      String currentDateStr = scanner.next();
      LocalDate saleDate = LocalDate.parse(currentDateStr);
      try {
        portfolio.removeStock(tickerSymbol, quantity, saleDate);
        view.displayMessage("Stock sold successfully.");
        break;
      } catch (IllegalArgumentException e) {
        view.displayMessage("Stock was not added, please try again.");
      }
    }
  }

}
