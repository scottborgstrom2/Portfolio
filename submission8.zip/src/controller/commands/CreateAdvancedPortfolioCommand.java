package controller.commands;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Scanner;

import model.IModelAdvanced;
import view.IView;

/**
 * CreateAdvancedPortfolio makes a new object of an advanced portfolio.
 * which is capable of handling a creation date and the "current" date of the portfolio.
 */
public class CreateAdvancedPortfolioCommand implements ICommand {
  /**
   * Constructor for the command create portfolio.
   */
  public CreateAdvancedPortfolioCommand() {
    //empty body
  }

  @Override
  public void run(IModelAdvanced model, Scanner scanner, IView view) throws IOException {
    view.displayMessage("Enter the name for this portfolio: ");
    String nameOfPortfolio = scanner.next();

    view.displayMessage("Enter creation date (YYYY-MM-DD): ");
    String creationDateStr = scanner.next();
    LocalDate creationDate = LocalDate.parse(creationDateStr);

    // Get the end date from the user
    view.displayMessage("Enter current date (YYYY-MM-DD): ");
    String currentDateStr = scanner.next();
    LocalDate currentDate = LocalDate.parse(currentDateStr);
    try {
      model.addPortfolioAdvanced(nameOfPortfolio, creationDate, currentDate);
      view.displayMessage("Your portfolio " + nameOfPortfolio + " has been created." );
    } catch (IllegalArgumentException e) {
      view.displayMessage("A portfolio with this name already exists!");
    }
  }
}
