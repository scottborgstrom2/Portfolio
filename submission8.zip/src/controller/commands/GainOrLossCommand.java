package controller.commands;

import model.IModelAdvanced;
import view.IView;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Scanner;

/**
 * This is a class that represents the command of a gain or loss function.
 * It executes an out print to the user to obtain inputs.
 * GainOrLoss computes the difference in a single stock over time.
 */
public class GainOrLossCommand extends AbstractCommand {

  /**
   * Constructor to create a gain or loss command.
   */
  public GainOrLossCommand() {
    super();
  }

  @Override
  public void run(IModelAdvanced model, Scanner scanner, IView view) throws IOException {
    super.run(model, scanner, view);
    view.displayMessage("Enter end date (YYYY-MM-DD): ");
    String endDateStr = scanner.next();

    LocalDate endDate = LocalDate.parse(endDateStr);

    while (endDate.isBefore(startDate)) {
      view.displayMessage("End date must be after the start date.");
      view.displayMessage("Enter end date (YYYY-MM-DD): ");
      endDateStr = scanner.next();
      endDate = LocalDate.parse(endDateStr);
    }
    while (model.getStock(tickerSymbol).getPrice(endDate) == 0) {
      view.displayMessage("Stock data isn't available; try again");
      view.displayMessage("Enter start date (YYYY-MM-DD): ");
      endDateStr = scanner.next();
      endDate = LocalDate.parse(endDateStr);
    }
    // to calculate
    double gainOrLoss = model.calculateGainLoss(tickerSymbol, startDate, endDate);
    view.displayMessage("Gain/Loss: $" + gainOrLoss);
  }
}
