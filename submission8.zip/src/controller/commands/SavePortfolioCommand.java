package controller.commands;

import java.io.IOException;
import java.util.Scanner;

import model.HandleFile;
import model.IModelAdvanced;
import model.IPortfolio;

import view.IView;

/**
 * Allows a user to save their portfolio into a file.
 * Will save the file and store all necessary information about a portfolio.
 */
public class SavePortfolioCommand implements ICommand {
  public SavePortfolioCommand() {
    //empty body to allow creation.
  }

  @Override
  public void run(IModelAdvanced model, Scanner scanner, IView view) throws IOException {
    view.displayMessage("Enter the name for the portfolio you want to save: ");
    String nameOfPortfolio = scanner.next();
    while (true) {
      try {
        IPortfolio portfolio = model.getPortfolio(nameOfPortfolio);
        HandleFile writeFile = new HandleFile(portfolio, model);
        writeFile.writeFile();
        view.displayMessage("File written successfully.");
        break;
      } catch (Exception e) {
        view.displayMessage("Portfolio not found. Please load or create a portfolio.");
        break;
      }
    }
  }
}
