package controller.commands;

import java.io.IOException;
import java.util.Scanner;

import model.IModelAdvanced;
import view.IView;

/**
 * Creates a portfolio as a command for the user to input.
 * This is the more basic implementation of a portfolio.
 */
public class CreatePortfolioCommand implements ICommand {
  /**
   * Constructor for the command create portfolio.
   */
  public CreatePortfolioCommand() {
    //empty body
  }

  @Override
  public void run(IModelAdvanced model, Scanner scanner, IView view) throws IOException {
    view.displayMessage("Enter the name for this portfolio: ");
    String nameOfPortfolio = scanner.next();
    try {
      model.addPortfolio(nameOfPortfolio);
      view.displayMessage("Your portfolio " + nameOfPortfolio + " has been created." );
    } catch (IllegalArgumentException e) {
      view.displayMessage("A portfolio with this name already exists!");
    }
  }
}
