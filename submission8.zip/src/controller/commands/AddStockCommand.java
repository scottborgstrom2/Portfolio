package controller.commands;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Scanner;

import model.IModelAdvanced;
import model.IPortfolio;
import view.IView;

/**
 * The add stock command similates a buying of a stock inside a requested portfolio.
 * Takes in a date of purchase, a integer quantity, and a target portfolio to accept these shares.
 */
public class AddStockCommand extends AbstractCommand {

  /**
   * Constructor to build the command.
   */
  public AddStockCommand() {
    //empty body to allow for a call.
  }

  @Override
  public void run(IModelAdvanced model, Scanner scanner, IView view) throws IOException {
    while (true) {
      view.displayMessage("Which portfolio do you want to add to: ");
      String portfolioName = scanner.next();
      IPortfolio portfolio;
      try {
        portfolio = model.getPortfolio(portfolioName);
        view.displayMessage("Portfolio " + portfolioName + " selected.");
      } catch (IllegalArgumentException e) {
        view.displayMessage("This portfolio does not exist. Please create a portfolio" +
                " by returning to the menu and creating one.");
        break;
      }
      view.displayMessage("Enter ticker symbol: ");
      String tickerSymbol = scanner.next();
      try  {
        model.fetchAndAddStock(tickerSymbol);
        view.displayMessage("Ticker symbol " + tickerSymbol + " selected.");
      } catch (Exception e) {
        view.displayMessage("Invalid ticker symbol. Please try again.");
      }
      view.displayMessage("Enter quantity: ");
      int quantity = scanner.nextInt();
      // Get the start date from the user
      view.displayMessage("Enter date of purchase (YYYY-MM-DD): ");
      String currentDateStr = scanner.next();
      LocalDate currentDate = LocalDate.parse(currentDateStr);
      if (currentDate.isBefore(portfolio.getDateOfCreation())) {
        view.displayMessage("Date of purchase cannot be before creation date. Please try again.");
        break;
      }
      try {
        portfolio.addStock(tickerSymbol, quantity, currentDate);
        view.displayMessage("Stock stored successfully.");
        break;
      } catch (IllegalArgumentException e) {
        view.displayMessage("Stock was not added, please try again.");
      }
    }
  }

}
