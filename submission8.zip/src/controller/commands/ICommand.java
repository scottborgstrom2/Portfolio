package controller.commands;

import model.IModelAdvanced;
import view.IView;

import java.io.IOException;
import java.util.Scanner;

/**
 * This interface represents a command that can be run on the program.
 */
public interface ICommand {
  /**
   * This method runs the command on the given scanner.
   * @param model is the model used.
   * @param scanner is the scanner given for inputs.
   */
  void run(IModelAdvanced model, Scanner scanner, IView view) throws IOException;
}
