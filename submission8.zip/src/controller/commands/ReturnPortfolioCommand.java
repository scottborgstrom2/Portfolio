package controller.commands;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Scanner;

import model.IModelAdvanced;
import model.IPortfolio;
import view.IView;

/**
 * Return Portfolio Command executes a summary of what the asked for portfolio.
 * contains and its value to confirm its existence.
 */
public class ReturnPortfolioCommand implements ICommand {

  /**
   * Constructor to build a return command.
   */
  public ReturnPortfolioCommand() {
    // empty body to create.
  }

  @Override
  public void run(IModelAdvanced model, Scanner scanner, IView view) throws IOException {
    view.displayMessage("Enter the name of the portfolio you want to view: ");
    String nameOfPortfolio = scanner.next();
    view.displayMessage("Enter start date (YYYY-MM-DD): ");
    String startDateStr = scanner.next();
    LocalDate startDate = LocalDate.parse(startDateStr);
    IPortfolio portfolio;
    try {
      portfolio = model.getPortfolio(nameOfPortfolio);
      view.displayMessage("Your portfolio " + nameOfPortfolio + " has been selected.");
      view.displayMessage(portfolio.distributionOfPortfolio(startDate, model));
      view.displayMessage("Your portfolio contains: \n" + portfolio.getPortfolioSummary());
    } catch (IllegalArgumentException e) {
      view.displayMessage(e.getMessage());
    }
  }
}

