package controller.commands;

import model.IModelAdvanced;

import model.IStock;
import view.IView;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Scanner;

/**
 * This class represents the command to visualize performance over time.
 * This aids in the user making decisions based on the performance of a portfolio or stock.
 */
public class PerformanceVisualizationCommand extends AbstractCommand {

  @Override
  public void run(IModelAdvanced model, Scanner scanner, IView view) throws IOException {
    // Determine whether it's a portfolio or a stock
    view.displayMessage("Enter 'portfolio' or 'stock': ");
    String type = scanner.next();
    boolean isPortfolio = type.equals("portfolio");

    // Get the name of the portfolio or stock
    view.displayMessage("Enter name of the portfolio or stock: ");
    String name = scanner.next();

    // Get the start date from the user
    view.displayMessage("Enter start date (YYYY-MM-DD): ");
    String startDateStr = scanner.next();
    startDate = LocalDate.parse(startDateStr);

    // Get the end date from the user
    view.displayMessage("Make sure there are at least 5 days between " +
            "the start and end dates inclusive: ");
    view.displayMessage("Enter end date (YYYY-MM-DD): ");
    String endDateStr = scanner.next();
    LocalDate endDate = LocalDate.parse(endDateStr);

    // might need while loop
    if (!isPortfolio) {
      try {
        IStock stock = model.getStock(name);
        if (stock == null) {
          model.fetchAndAddStock(name);
        }
      } catch (IllegalArgumentException e) {
        view.displayMessage("Ticker not found. Enter ticker symbol: ");
        tickerSymbol = scanner.next();
      }
    }

    try {
      String barChart = model.visualizePerformance(name, startDate, endDate, isPortfolio);
      view.displayMessage(barChart);
    } catch (IllegalArgumentException e) {
      view.displayMessage("Error: " + e.getMessage());
    }
  }
}
