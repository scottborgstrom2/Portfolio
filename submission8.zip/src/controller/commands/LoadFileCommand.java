package controller.commands;

import java.io.File;

import java.io.IOException;
import java.util.Scanner;

import model.HandleFile;

import model.IModelAdvanced;
import model.IPortfolio;
import view.IView;

/**
 * LoadFile command executes to reading/parsing of a user inputting a file to be accepted.
 * As a portfolio being loaded and saved.
 */
public class LoadFileCommand implements ICommand {

  @Override
  public void run(IModelAdvanced model, Scanner scanner, IView view) throws IOException {
    view.displayMessage("Make sure the file name is just the tickerSymbol.txt: ");
    view.displayMessage("Enter the name for the portfolio you want to load: ");
    String fileName = scanner.next();
    File file = new File("resources/" + fileName + ".txt");
    HandleFile loadFile = new HandleFile(file, model);
    try {
      IPortfolio portfolio = loadFile.readFile();
      view.displayMessage("Portfolio: " + portfolio.toString() + "stored.");
    } catch (Exception e) {
      view.displayMessage(e.getMessage());
    }
  }
}
