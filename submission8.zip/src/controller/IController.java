package controller;

import java.io.IOException;

import model.IModelAdvanced;

/**
 * IController is an interface that represents all controllers.
 * for this program.
 */
public interface IController {
  /**
   * Go is a method that executes the relationship between model and controller.
   * @param model is the model taken in and considered.
   */
  void goController(IModelAdvanced model) throws IOException;
}
