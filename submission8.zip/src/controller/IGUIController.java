package controller;

/**
 * IGUIController is an interface that represents all GUI controllers.
 * for this program.
 */
public interface IGUIController extends IController {

}
