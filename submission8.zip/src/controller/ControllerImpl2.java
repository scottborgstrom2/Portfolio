package controller;

import controller.commands.CreateAdvancedPortfolioCommand;
import controller.commands.LoadFileCommand;
import controller.commands.PerformanceVisualizationCommand;
import controller.commands.RebalancePortfolioCommand;
import controller.commands.SavePortfolioCommand;

/**
 * ControllerImpl2 is the second implementation of a controller that.
 * represents the crossover between user view and program logic.
 * The second implementation delegates new functionality to be implemented here.
 * while extending the old controller.
 */
public class ControllerImpl2 extends ControllerImpl {
  /**
   * Constructor that takes in output and input and handling new commands.
   * The new implementation handles unforeseen additions to the program.
   *
   * @param out represents an appendable output.
   * @param in  represents a readable in.
   */
  public ControllerImpl2(Appendable out, Readable in) {
    super(out, in);
    commandMap.put("VisualizePerformance", new PerformanceVisualizationCommand());
    commandMap.put("SavePortfolio", new SavePortfolioCommand());
    commandMap.put("CreatePortfolio", new CreateAdvancedPortfolioCommand());
    commandMap.put("LoadFile", new LoadFileCommand());
    commandMap.put("Rebalance", new RebalancePortfolioCommand());
  }
}
