package controller;

import controller.guicommands.GUIBuyStockCommand;
import controller.guicommands.GUICreatePortfolioCommand;
import controller.guicommands.GUILoadPortfolioCommand;
import controller.guicommands.GUIPortfolioSummaryCommand;
import controller.guicommands.GUIPortfolioValueCommand;
import controller.guicommands.GUISavePortfolioCommand;
import controller.guicommands.GUISellStockCommand;
import controller.guicommands.IGUICommand;
import model.IModelAdvanced;
import view.GUIView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

/**
 * This interface represents the GUI controller for the Portfolio Management System.
 * It declares methods for handling user interactions with the GUI.
 */
public class GUIController implements IGUIController {
  private final IModelAdvanced model;
  private final GUIView view;

  /**
   * Constructs a GUIController with the specified view and model.
   *
   * @param view the GUI view
   * @param model the model
   */
  public GUIController(IModelAdvanced model, GUIView view) {
    this.model = model;
    this.view = view;
    setupListeners();
  }

  private void setupListeners() {
    view.setCreatePortfolioAction(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        executeCommand(new GUICreatePortfolioCommand(model, view));
      }
    });

    view.setBuyStockAction(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        executeCommand(new GUIBuyStockCommand(model, view));
      }
    });

    view.setSellStockAction(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        executeCommand(new GUISellStockCommand(model, view));
      }
    });

    view.setPortfolioSummaryAction(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        executeCommand(new GUIPortfolioSummaryCommand(model, view));
      }
    });

    view.setPortfolioValueAction(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        executeCommand(new GUIPortfolioValueCommand(model, view));
      }
    });

    view.setSavePortfolioAction(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        executeCommand(new GUISavePortfolioCommand(model, view));
      }
    });

    view.setRetrievePortfolioAction(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        executeCommand(new GUILoadPortfolioCommand(model, view));
      }
    });
  }

  private void executeCommand(IGUICommand command) {
    try {
      command.execute();
    } catch (Exception e) {
      view.updateDisplayArea("Error executing command: " + e.getMessage());
    }
  }

  @Override
  public void goController(IModelAdvanced model) throws IOException {
    this.view.setVisible(true);
    view.updateDisplayArea("Welcome to the GUI Interface");
  }
}
