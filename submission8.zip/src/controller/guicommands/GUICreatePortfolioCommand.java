package controller.guicommands;

import model.IModelAdvanced;
import view.GUIView;

import java.time.LocalDate;

/**
 * This class represents a GUI command for creating a portfolio.
 * It extends the GUIAbstractCommand class and implements the execute method.
 */
public class GUICreatePortfolioCommand extends GUIAbstractCommand {

  /**
   * Constructs a GUICreatePortfolioCommand with the given model and view.
   *
   * @param model the model to be used by the command
   * @param view the view to be used by the command
   */
  public GUICreatePortfolioCommand(IModelAdvanced model, GUIView view) {
    super(model, view);
  }

  @Override
  public void execute() {
    try {
      String portfolioName = view.getPortfolioNameCreatePortfolio();
      LocalDate creationDate = LocalDate.parse(view.getCreationDateCreatePortfolio());
      LocalDate currentDate = LocalDate.parse(view.getCurrentDateCreatePortfolio());
      model.addPortfolioAdvanced(portfolioName, creationDate, currentDate);
      view.updateDisplayArea("Portfolio " + portfolioName + " created successfully.");
    } catch (Exception e) {
      view.updateDisplayArea("Error creating portfolio: " + e.getMessage());
    }
  }
}
