package controller.guicommands;

import model.IModelAdvanced;
import view.GUIView;

/**
 * This is an abstract class that represents a GUI command that can be executed.
 * It provides a base implementation for GUI commands, with a reference to the model and view.
 */
public abstract class GUIAbstractCommand implements IGUICommand {
  protected final IModelAdvanced model;
  protected final GUIView view;

  /**
   * Constructs a GUI command with the given model and view.
   *
   * @param model the model to be used by the command
   * @param view  the view to be used by the command
   */
  public GUIAbstractCommand(IModelAdvanced model, GUIView view) {
    this.model = model;
    this.view = view;
  }

  /**
   * Executes the GUI command.
   */
  public abstract void execute();
}
