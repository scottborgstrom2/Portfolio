package controller.guicommands;

import model.HandleFile;
import model.IModelAdvanced;
import view.GUIView;

/**
 * This class represents a GUI command for loading a portfolio.
 * It extends the GUIAbstractCommand class and implements the execute method.
 */
public class GUILoadPortfolioCommand extends GUIAbstractCommand {

  /**
   * This class represents a GUI command for loading a portfolio.
   * It extends the GUIAbstractCommand class and implements the execute method.
   */
  public GUILoadPortfolioCommand(IModelAdvanced model, GUIView view) {
    super(model, view);
  }

  @Override
  public void execute() {
    try {
      String portfolioName = view.getLoadPortfolioName();
      HandleFile handleFile = new HandleFile(new java.io.File("resources/" +
              portfolioName + ".txt"), model);
      handleFile.readFile();
      view.updateDisplayArea("Portfolio " + portfolioName + " loaded successfully.");
    } catch (Exception e) {
      view.updateDisplayArea("Error loading portfolio: " + e.getMessage());
    }
  }
}
