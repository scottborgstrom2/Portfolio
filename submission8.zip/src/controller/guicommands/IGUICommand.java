package controller.guicommands;

/**
 * This interface represents a GUI command that can be executed.
 * Each GUI command implements the execute method.
 */
public interface IGUICommand {
  /**
   * Executes the GUI command.
   */
  void execute();
}