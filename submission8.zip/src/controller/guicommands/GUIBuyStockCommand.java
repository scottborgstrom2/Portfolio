package controller.guicommands;

import model.IModelAdvanced;
import view.GUIView;

import java.time.LocalDate;


/**
 * This class represents a GUI command for buying stocks.
 * It extends the GUIAbstractCommand class and implements the execute method.
 */
public class GUIBuyStockCommand extends GUIAbstractCommand {

  /**
   * Constructs a GUIBuyStockCommand with the given model and view.
   *
   * @param model the model to be used by the command
   * @param view  the view to be used by the command
   */
  public GUIBuyStockCommand(IModelAdvanced model, GUIView view) {
    super(model, view);
  }

  @Override
  public void execute() {
    try {
      String portfolioName = view.getBuySellPortfolioName();
      String stock = view.getStockSymbol();
      int shares = 0;
      try {
        shares = Integer.parseInt(view.getShares());
      } catch (Exception e) {
        view.updateDisplayArea("Cannot input non-integer value for shares.");
        return;
      }
      LocalDate date = LocalDate.parse(view.getDate());
      model.getPortfolio(portfolioName).addStock(stock, shares, date);
      view.updateDisplayArea("Bought " + shares + " shares of " + stock + " on " +
              date + " in portfolio " + portfolioName);
    } catch (Exception e) {
      view.updateDisplayArea("Error buying stock: " + e.getMessage());
    }
  }
}
