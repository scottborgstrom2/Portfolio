package controller.guicommands;

import model.IModelAdvanced;
import view.GUIView;

import java.time.LocalDate;

/**
 * This class represents a GUI command for displaying a portfolio value.
 * It extends the GUIAbstractCommand class and implements the execute method.
 */
public class GUIPortfolioValueCommand extends GUIAbstractCommand {

  /**
   * Constructs a GUIPortfolioValueCommand with the given model and view.
   *
   * @param model the model to be used by the command
   * @param view the view to be used by the command
   */
  public GUIPortfolioValueCommand(IModelAdvanced model, GUIView view) {
    super(model, view);
  }

  @Override
  public void execute() {
    try {
      String portfolioName = view.getPortfolioValueName();
      LocalDate date = LocalDate.parse(view.getPortfolioValueDate());
      double portfolioValue = model.getPortfolio(portfolioName).getPortfolioValue(date, model);
      view.updateDisplayArea("Portfolio value of " + portfolioName + " on " +
              date + ":\n" + portfolioValue);
    } catch (Exception e) {
      view.updateDisplayArea("Error getting portfolio value: " + e.getMessage());
    }
  }
}
