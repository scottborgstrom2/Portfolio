package controller.guicommands;

import java.time.LocalDate;

import model.IModelAdvanced;
import view.GUIView;

/**
 * This class represents a GUI command for loading a portfolio.
 * It extends the GUIAbstractCommand class and implements the execute method.
 */
public class GUIPortfolioSummaryCommand extends GUIAbstractCommand {

  /**
   * Constructs a GUIPortfolioSummaryCommand with the given model and view.
   *
   * @param model the model to be used by the command
   * @param view the view to be used by the command
   */
  public GUIPortfolioSummaryCommand(IModelAdvanced model, GUIView view) {
    super(model, view);
  }

  @Override
  public void execute() {
    try {
      String portfolioName = view.getPortfolioSummaryName();
      String dateOfSummary = view.getPortfolioSummaryDate();
      String summary = model.getPortfolio(portfolioName)
              .distributionOfPortfolio(LocalDate.parse(dateOfSummary), model);
      String summary2 = model.getPortfolio(portfolioName).getPortfolioSummary();
      view.updateDisplayArea("Portfolio summary of " + portfolioName + ":\n" + summary
              + "\n" + summary2);
    } catch (Exception e) {
      view.updateDisplayArea("Error getting portfolio summary: " + e.getMessage());
    }
  }
}
