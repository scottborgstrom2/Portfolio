package controller.guicommands;

import model.IModelAdvanced;
import view.GUIView;

import java.time.LocalDate;

/**
 * This class represents a GUI command for selling stocks.
 * It extends the GUIAbstractCommand class and implements the execute method.
 */
public class GUISellStockCommand extends GUIAbstractCommand {

  /**
   * Constructs a GUISellStockCommand with the given model and view.
   *
   * @param model the model to be used by the command
   * @param view the view to be used by the command
   */
  public GUISellStockCommand(IModelAdvanced model, GUIView view) {
    super(model, view);
  }

  @Override
  public void execute() {
    try {
      String portfolioName = view.getBuySellPortfolioName();
      String stock = view.getStockSymbol();
      int shares = Integer.parseInt(view.getShares());
      LocalDate date = LocalDate.parse(view.getDate());
      model.getPortfolio(portfolioName).removeStock(stock, shares, date);
      view.updateDisplayArea("Sold " + shares + " shares of " + stock + " on " +
              date + " from portfolio " + portfolioName);
    } catch (Exception e) {
      view.updateDisplayArea("Error selling stock: " + e.getMessage());
    }
  }
}
