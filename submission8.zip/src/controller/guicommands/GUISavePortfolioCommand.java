package controller.guicommands;

import model.HandleFile;
import model.IModelAdvanced;
import view.GUIView;

/**
 * This class represents a GUI command for saving a portfolio.
 * It extends the GUIAbstractCommand class and implements the execute method.
 */
public class GUISavePortfolioCommand extends GUIAbstractCommand {

  /**
   * Constructs a GUISavePortfolioCommand with the given model and view.
   *
   * @param model the model to be used by the command
   * @param view the view to be used by the command
   */
  public GUISavePortfolioCommand(IModelAdvanced model, GUIView view) {
    super(model, view);
  }

  @Override
  public void execute() {
    try {
      String portfolioName = view.getSavePortfolioName();
      HandleFile handleFile = new HandleFile(model.getPortfolio(portfolioName), model);
      handleFile.writeFile();
      view.updateDisplayArea("Portfolio " + portfolioName + " saved successfully.");
    } catch (Exception e) {
      view.updateDisplayArea("Error saving portfolio: " + e.getMessage());
    }
  }
}
