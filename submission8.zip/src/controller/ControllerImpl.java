package controller;

import controller.commands.AddStockCommand;
import controller.commands.CalculateCrossoverCommand;
import controller.commands.CreatePortfolioCommand;
import controller.commands.GainOrLossCommand;
import controller.commands.ICommand;
import controller.commands.MovingAverageCommand;
import controller.commands.RemoveStockCommand;
import controller.commands.ReturnPortfolioCommand;
import model.IModelAdvanced;
import view.IView;
import view.TextView;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Scanner;

/**
 * ControllerImpl is an implementation of controller that represents
 * the crossover between the logic in model and what the client wants to see.
 */
public class ControllerImpl implements IController {
  protected final Map<String, ICommand> commandMap;
  protected final Appendable out;
  protected final Readable in;

  /**
   * Constructor that takes in output and input.
   *
   * @param out represents an appendable output.
   * @param in  represents a readable in.
   */
  public ControllerImpl(Appendable out, Readable in) {
    commandMap = new HashMap<>();
    commandMap.put("GainOrLoss", new GainOrLossCommand());
    commandMap.put("MovingAverage", new MovingAverageCommand());
    commandMap.put("Crossover", new CalculateCrossoverCommand());
    commandMap.put("CreatePortfolio", new CreatePortfolioCommand());
    commandMap.put("AddStock", new AddStockCommand());
    commandMap.put("RemoveStock", new RemoveStockCommand());
    commandMap.put("ReturnPortfolio", new ReturnPortfolioCommand());

    this.out = Objects.requireNonNull(out);
    this.in = Objects.requireNonNull(in);
  }

  @Override
  public void goController(IModelAdvanced model) throws IOException {
    try (Scanner scanner = new Scanner(this.in)) {
      IView view = new TextView(in, out);
      view.displayMenu();
      while (true) {
        if (scanner.hasNext()) {
          String command = scanner.next();
          if (command.equalsIgnoreCase("q")) {
            return;
          }
          ICommand commandToRun = this.commandMap.getOrDefault(command, null);
          if (commandToRun != null) {
            try {
              commandToRun.run(model, scanner, view);
            } catch (IOException e) {
              view.displayMessage("An error occurred: " + e.getMessage());
            }
          } else {
            view.displayMessage("Invalid command. Please try again.");
          }
        }
      }
    }
  }
}