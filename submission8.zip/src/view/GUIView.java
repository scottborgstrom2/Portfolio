package view;


import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

import java.awt.Dimension;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Font;

import java.awt.event.ActionListener;

/**
 * This class represents the GUI view for the Portfolio Management System.
 * It extends JFrame and implements IGUIView, containing various components for user interaction.
 */
public class GUIView extends JFrame implements IGUIView {
  private JTextArea displayArea;
  private JTextField portfolioNameField;
  private JTextField creationDateField;
  private JTextField currentDateField;
  private JTextField buySellPortfolioNameField;
  private JTextField stockSymbolField;
  private JTextField sharesField;
  private JTextField dateField;
  private JTextField portfolioSummaryNameField;
  private JTextField portfolioSummaryDateField;
  private JTextField portfolioValueNameField;
  private JTextField portfolioValueDateField;
  private JTextField savePortfolioNameField;
  private JTextField loadPortfolioNameField;

  private JButton createPortfolioButton;
  private JButton buyStockButton;
  private JButton sellStockButton;
  private JButton portfolioSummaryButton;
  private JButton portfolioValueButton;
  private JButton savePortfolioButton;
  private JButton retrievePortfolioButton;

  /**
   * Constructs a GUIView with the specified layout and components.
   */
  public GUIView() {
    super("Portfolio Management");
    setSize(new Dimension(800, 600));
    setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    setLayout(new BorderLayout());

    // Title
    JLabel titleLabel = new JLabel("Portfolio Management System", JLabel.CENTER);
    titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
    add(titleLabel, BorderLayout.NORTH);

    // Display Area
    displayArea = new JTextArea(10, 40);
    displayArea.setEditable(false);
    add(new JScrollPane(displayArea), BorderLayout.CENTER);

    // Input and Buttons Panel
    JPanel inputPanel = new JPanel();

    //design new pannel
    inputPanel.setLayout(new GridLayout(8, 1));

    // Create Portfolio Section
    JPanel createPortfolioPanel = new JPanel();
    createPortfolioPanel.add(new JLabel("Portfolio Name:"));
    portfolioNameField = new JTextField(10);
    createPortfolioPanel.add(portfolioNameField);
    createPortfolioPanel.add(new JLabel("Creation Date (YYYY-MM-DD):"));
    creationDateField = new JTextField(10);
    createPortfolioPanel.add(creationDateField);
    createPortfolioPanel.add(new JLabel("Current Date (YYYY-MM-DD):"));
    currentDateField = new JTextField(10);
    createPortfolioPanel.add(currentDateField);
    createPortfolioButton = new JButton("Create Portfolio");
    createPortfolioPanel.add(createPortfolioButton);
    inputPanel.add(createPortfolioPanel);

    // Buy/Sell Stocks Section
    JPanel buySellPanel = new JPanel();
    buySellPanel.add(new JLabel("Portfolio Name:"));
    buySellPortfolioNameField = new JTextField(10);
    buySellPanel.add(buySellPortfolioNameField);
    buySellPanel.add(new JLabel("Stock Symbol:"));
    stockSymbolField = new JTextField(5);
    buySellPanel.add(stockSymbolField);
    buySellPanel.add(new JLabel("Shares:"));
    sharesField = new JTextField(5);
    buySellPanel.add(sharesField);
    buySellPanel.add(new JLabel("Date (YYYY-MM-DD):"));
    dateField = new JTextField(10);
    buySellPanel.add(dateField);
    buyStockButton = new JButton("Buy Stock");
    buySellPanel.add(buyStockButton);
    sellStockButton = new JButton("Sell Stock");
    buySellPanel.add(sellStockButton);
    inputPanel.add(buySellPanel);

    // Portfolio Summary Section
    JPanel summaryPanel = new JPanel();
    summaryPanel.add(new JLabel("Portfolio Name:"));
    portfolioSummaryNameField = new JTextField(10);
    summaryPanel.add(portfolioSummaryNameField);
    summaryPanel.add(new JLabel("Summary Date (YYYY-MM-DD):"));
    portfolioSummaryDateField = new JTextField(10);
    summaryPanel.add(portfolioSummaryDateField);
    portfolioSummaryButton = new JButton("Get Portfolio Summary");
    summaryPanel.add(portfolioSummaryButton);
    inputPanel.add(summaryPanel);

    // Portfolio Value Section
    JPanel valuePanel = new JPanel();
    valuePanel.add(new JLabel("Portfolio Name:"));
    portfolioValueNameField = new JTextField(10);
    valuePanel.add(portfolioValueNameField);
    valuePanel.add(new JLabel("Value Date (YYYY-MM-DD):"));
    portfolioValueDateField = new JTextField(10);
    valuePanel.add(portfolioValueDateField);
    portfolioValueButton = new JButton("Get Portfolio Value");
    valuePanel.add(portfolioValueButton);
    inputPanel.add(valuePanel);

    // Save Portfolio Section
    JPanel savePanel = new JPanel();
    savePanel.add(new JLabel("Save Portfolio Name:"));
    savePortfolioNameField = new JTextField(10);
    savePanel.add(savePortfolioNameField);
    savePortfolioButton = new JButton("Save Portfolio");
    savePanel.add(savePortfolioButton);
    inputPanel.add(savePanel);

    // Retrieve Portfolio Section
    JPanel retrievePanel = new JPanel();
    retrievePanel.add(new JLabel("Load Portfolio Name:"));
    loadPortfolioNameField = new JTextField(10);
    retrievePanel.add(loadPortfolioNameField);
    retrievePortfolioButton = new JButton("Retrieve Portfolio");
    retrievePanel.add(retrievePortfolioButton);
    inputPanel.add(retrievePanel);

    // Add the input panel to the frame
    add(inputPanel, BorderLayout.SOUTH);

    pack();
  }

  @Override
  public void setCreatePortfolioAction(ActionListener actionListener) {
    createPortfolioButton.addActionListener(actionListener);
  }

  @Override
  public void setBuyStockAction(ActionListener actionListener) {
    buyStockButton.addActionListener(actionListener);
  }

  @Override
  public void setSellStockAction(ActionListener actionListener) {
    sellStockButton.addActionListener(actionListener);
  }

  @Override
  public void setPortfolioSummaryAction(ActionListener actionListener) {
    portfolioSummaryButton.addActionListener(actionListener);
  }

  @Override
  public void setPortfolioValueAction(ActionListener actionListener) {
    portfolioValueButton.addActionListener(actionListener);
  }

  @Override
  public void setSavePortfolioAction(ActionListener actionListener) {
    savePortfolioButton.addActionListener(actionListener);
  }

  @Override
  public void setRetrievePortfolioAction(ActionListener actionListener) {
    retrievePortfolioButton.addActionListener(actionListener);
  }

  @Override
  public String getPortfolioNameCreatePortfolio() {
    return portfolioNameField.getText();
  }

  @Override
  public String getCreationDateCreatePortfolio() {
    return creationDateField.getText();
  }

  @Override
  public String getCurrentDateCreatePortfolio() {
    return currentDateField.getText();
  }

  @Override
  public String getBuySellPortfolioName() {
    return buySellPortfolioNameField.getText();
  }

  @Override
  public String getStockSymbol() {
    return stockSymbolField.getText();
  }

  @Override
  public String getShares() {
    return sharesField.getText();
  }

  @Override
  public String getDate() {
    return dateField.getText();
  }

  @Override
  public String getPortfolioSummaryName() {
    return portfolioSummaryNameField.getText();
  }

  @Override
  public String getPortfolioSummaryDate() {
    return portfolioSummaryDateField.getText();
  }

  @Override
  public String getPortfolioValueName() {
    return portfolioValueNameField.getText();
  }

  @Override
  public String getPortfolioValueDate() {
    return portfolioValueDateField.getText();
  }

  @Override
  public String getSavePortfolioName() {
    return savePortfolioNameField.getText();
  }

  @Override
  public String getLoadPortfolioName() {
    return loadPortfolioNameField.getText();
  }

  @Override
  public void updateDisplayArea(String message) {
    displayArea.setText(message);
  }
}