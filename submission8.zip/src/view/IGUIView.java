package view;

import java.awt.event.ActionListener;

/**
 * This interface represents the GUI view for the Portfolio Management System.
 * It declares methods for setting action listeners and getting user inputs.
 */
public interface IGUIView {

  /**
   * Sets the action listener for the create portfolio button.
   * @param actionListener the action listener to be set
   */
  public void setCreatePortfolioAction(ActionListener actionListener);

  /**
   * Sets the action listener for the buy stock portfolio button.
   * @param actionListener the action listener to be set
   */
  public void setBuyStockAction(ActionListener actionListener);

  /**
   * Sets the action listener for the sell stock button.
   * @param actionListener the action listener to be set
   */
  public void setSellStockAction(ActionListener actionListener);

  /**
   * Sets the action listener for the portfolio summary button.
   * @param actionListener the action listener to be set
   */
  public void setPortfolioSummaryAction(ActionListener actionListener);

  /**
   * Sets the action listener for the portfolio value button.
   * @param actionListener the action listener to be set
   */
  public void setPortfolioValueAction(ActionListener actionListener);

  /**
   * Sets the action listener for the save portfolio button.
   * @param actionListener the action listener to be set
   */
  public void setSavePortfolioAction(ActionListener actionListener);

  /**
   * Sets the action listener for the retrieve portfolio button.
   * @param actionListener the action listener to be set
   */
  public void setRetrievePortfolioAction(ActionListener actionListener);

  /**
   * Returns the portfolio name entered by the user for creating a portfolio.
   * @return the portfolio name
   */
  public String getPortfolioNameCreatePortfolio();

  /**
   * Returns the creation date entered by the user for creating a portfolio.
   * @return the creation date
   */
  public String getCreationDateCreatePortfolio();

  /**
   * Returns the current date entered by the user for creating a portfolio.
   * @return the current date
   */
  public String getCurrentDateCreatePortfolio();

  /**
   * Returns the portfolio name entered by the user for buying or selling stocks.
   * @return the portfolio name
   */
  public String getBuySellPortfolioName();

  /**
   * Returns the stock symbol entered by the user.
   * @return the stock symbol
   */
  public String getStockSymbol();

  /**
   * Returns the number of shares entered by the user.
   * @return the number of shares
   */
  public String getShares();

  /**
   * Returns the date entered by the user.
   * @return the date
   */
  public String getDate();

  /**
   * Returns the portfolio name entered by the user for the portfolio summary.
   * @return the portfolio name
   */
  public String getPortfolioSummaryName();

  /**
   * Returns the date entered by the user for the portfolio summary.
   * @return the date
   */
  public String getPortfolioSummaryDate();

  /**
   * Returns the portfolio name entered by the user for the portfolio value.
   * @return the portfolio name
   */
  public String getPortfolioValueName();

  /**
   * Returns the date entered by the user for the portfolio value.
   * @return the date
   */
  public String getPortfolioValueDate();

  /**
   * Returns the name entered by the user for saving the portfolio.
   * @return the name for saving the portfolio
   */
  public String getSavePortfolioName();

  /**
   * Returns the name entered by the user for loading the portfolio.
   * @return the name for loading the portfolio
   */
  public String getLoadPortfolioName();

  /**
   * Updates the display area with the specified message.
   *
   * @param message the message to be displayed
   */
  public void updateDisplayArea(String message);
}