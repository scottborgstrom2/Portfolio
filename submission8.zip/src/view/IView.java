package view;

import java.io.IOException;


/**
 * This interface represents a view that the client can interact with.
 */
public interface IView {
  /**
   * Display menu returns a message that represents all options a user has for input.
   * @throws IOException to handle the appending.
   */
  void displayMenu() throws IOException;

  /**
   * Display gain or loss returns a message that represents the result of a GainLoss command.
   * @throws IOException to handle the appending.
   */
  void displayGainLoss(double gainLoss) throws IOException;

  /**
   * Display crossover returns a message that represents the result of a crossover command.
   * @throws IOException to handle the appending.
   */
  void displayCrossover(double crossover) throws IOException;

  /**
   * Display moving average returns a message that represents.
   * the result of the moving average command.
   * @throws IOException to handle the appending.
   */
  void displayMovingAverage(double movingAverage) throws IOException;

  /**
   * Display message returns a message given to it in the parameter to the view.
   * @throws IOException to handle the appending.
   */
  void displayMessage(String message) throws IOException;

}