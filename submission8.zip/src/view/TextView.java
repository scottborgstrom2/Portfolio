package view;

import java.io.IOException;
import java.util.Scanner;

/**
 * This text view represents the actual interaction between the program.
 * and the user.
 */
public class TextView implements IView {
  private Appendable output;

  /**
   * Constructor to create a text view to interact with the user.
   * @param in is the input taken in.
   * @param output is the output that will be appended and displayed.
   */
  public TextView(Readable in, Appendable output) {
    Scanner scanner = new Scanner(in);
    this.output = output;
  }

  @Override
  public void displayMenu() throws IOException {
    this.output.append("Menu options:\n\n");
    this.output.append("To view g/l type: GainOrLoss\n");
    this.output.append("To view moving average type: MovingAverage\n");
    this.output.append("To view crossover days: Crossover\n");
    this.output.append("To create a new portfolio: CreatePortfolio\n");
    this.output.append("To buy a stock to a portfolio: AddStock\n");
    this.output.append("To sell a stock from a portfolio: RemoveStock\n");
    this.output.append("To return a summary of a portfolio: ReturnPortfolio\n");
    this.output.append("To display a graph to analyze a stock or portfolio: " +
            "VisualizePerformance\n");
    this.output.append("To rebalance a portfolio: Rebalance\n");
    this.output.append("To locally save a portfolio: SavePortfolio\n");
    this.output.append("To import a portfolio: LoadFile\n");
    this.output.append("To quit type: q\n");
  }

  @Override
  public void displayGainLoss(double gainLoss) throws IOException {
    this.output.append("Gain/Loss: $" + gainLoss + "\n");
  }

  @Override
  public void displayMovingAverage(double movingAverage) throws IOException {
    this.output.append("Moving Average: $" + movingAverage + "\n");
  }

  @Override
  public void displayCrossover(double crossover) throws IOException {
    this.output.append("Crossover: " + crossover + "\n");
  }

  @Override
  public void displayMessage(String message) throws IOException {
    this.output.append(message + "\n");
  }


}