import controller.ControllerImpl2;
import controller.GUIController;
import controller.IGUIController;
import model.IModelAdvanced;
import model.ModelImpl2;
import view.GUIView;


import java.io.IOException;
import java.io.InputStreamReader;

/**
 * The main class is where the program is actually executed.
 */
public class Main {
  /**
   * Where the main is run.
   * @param args is the String to be run.
   * @throws IOException if the program is unable to run.
   */
  public static void main(String[] args) throws IOException {
    InputStreamReader in = new InputStreamReader(System.in);
    Appendable out = System.out;

    IModelAdvanced model = new ModelImpl2();

    if (args.length > 0 && args[0].equals("-text")) {
      ControllerImpl2 textController = new ControllerImpl2(out, in);
      textController.goController(model);
    } else {
      GUIView guiView = new GUIView();
      IGUIController guiController = new GUIController(model, guiView);
      guiController.goController(model);
    }
  }
}
