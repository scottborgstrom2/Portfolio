# DESIGN-README.txt File: Stock Project Approach & Explanations - CS3500 - Harrison Do>

Overview of the project - Our project is mainly focused on the design at this point. We have a
working program( when working directly with the AlphaVantage API) that supports text based
interaction between the user and the software.

Design goals: Our design goals were to firstly fit what we have been learning in class, but also
keeping in mind that we will be adding onto this project.

Architecture and design patterns used: Our design used the model view controller pattern as well as
the command design pattern.

Key components and their responsibilities: Controller: controls the relationship between the user
and the data. Model: Can retrieve data about a stock and then has the ability to preform operations
with that data. View: Present information to the user.

Design considerations: We extended the Model and the Controller using the interface to extend and
make a new implementation. We moved all functions that could be utilized in the new implementation there.
In order to keep the code clean and true to what we had submitted last week. We updated calls of IModel to
IModelAdvanced in order to utilize new functions inside of the controller and the command pattern. We chose not
to create a new interface for portfolio because of the scope issues associated. Inside we justified our design choice
with TAs but making sure we still followed SOLID design principles. We created an AdvancedPortfolio that extends Portfolio
and has new fields. Portfolio is basically outdated but still is able to be read and utilized. We created a PurchaseRecord class
and decided against making it protected because it is a fairly straight forward design and does not allow the user any
mutation that could dramatically affect the program.

View Considerations: We have a text based view that is able to interact with the user. We have a
scanner that reads the input. We also have a graphical user interface which displays a visual
way for the user to take advantage of certain functions. There are text boxes in which the user will
input their data and then press a button to execute the command. There are action listeners that
will take the data from the text boxes and then execute the command.