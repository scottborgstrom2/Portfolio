# README.md File: Stock Project Approach & Explanations - CS3500 -
Harrison Dolgoff & Scott Borgstrom


## Approach


- This project involved designing and implementing a way to pull information about a stock using an 
API/local data and perform three types of operations or create a portfolio. My partner and I chose
to focus on the design of our code and making sure that we are able to have a strong foundation for 
the upcoming additions to the original stock assignment.



## Setup


- Controller that controls the relationship between the user and the data with operations being 
preformed on it.
- Controller also has an interface, IController, to allow simple reading when
new commands are introduced.

- Model which uses an API to retrieve data about a stock and then has the ability to preform 
operations.
- Model has an interface, in which new implementations / iterations of code can be added to new
models if it doesn't affect the foundation of the code.
- A new implementation, ModelImpl2 was utilized for the addition of new features, more to be
discussed below.

- View which is able to display anything to the output/user.

- Error Handling: Implemented error handling mechanisms to handle null inputs to the model, 
as well as pulling null information from the API
Also, anywhere where Exceptions are thrown, we catch them and display to the user their mistake.





## Challenges Faced


- There were a few miscommunications between my partner and I which were the main problems for us 
during this assignment. Both of us did a good job staying accountable.


- In the first assignment, with a limited API key, there was a problem parsing through LocalData.
However, with a high-limit API key, we can keep our resources clean and focus on retrieving data.

- Implementing the new view was tough due to the extension of view and lack of experience with JFrame.
However, after learning the formatting, we had all the necessary components to make this experience easy.




## Testing


- Performance Eval: Tested the ModelImpl to make sure that all of the commands are properly working.


- Error Testing: Tested error handling in regard to the ModelImpl


- Stock: Tested the stock class by creating a mock example.

- Controller: Our controller has testing which shows it can handle inputs as well as improper 
inputs.



## Implementation


- As of right now our controller and commands have been successfully implemented and are fully 
functional when working with the API data as well as local data for google.

- An advanced portfolio was created to handle new features, those include:
- Purchasing and selling stocks on specific dates.
- Being able to load in files, parse through and save them to the program.
- Being able to persist portfolios by writing a .txt file for the user when they want to save.
- Computing X-day moving average, gain or loss over a period, x-day crossover for stocks in the API.
- Rebalancing of a portfolio on a given date with weights given in by the user that amount to 100.
- Plotting a bar chart to visualize the performance of a portfolio or stock over time.
- Determining the value and distribution of a portfolio on a specific date.

- The view of our program has been fully implemented and is fully functional.
- A secondary, but preferred, GUI view has been implemented but only displays users what the assignment
requires. This means that when using the GUI, the user cannot visualize the portfolio or stock data.
The user can only:
- Create a portfolio
- Load and save a portfolio
- Buy and sell stocks quantities (only whole numbers) on dates.
- Query the value and composition of a portfolio on a date
In order to utilize all features from above, the user should access the text-based view.

- The testing for our code is fairly extensive and show that all of the functions
implemented work.
- Given that ModelImpl2 is now the standard and extends ModelImpl1, we replaced
all calls of ModelImpl1 to 2.

