# SETUP-README.txt File: Stock Project Approach & Explanations - CS3500 - Harrison Do>

In order to run our code from the jar, you will find the file in the artifacts folder inside
of "out" then you will need to open the code into an IDE or just in your terminal. From here you
will run the main function and then can access and interact with the program. You do not need to be
in a special directory. However, if you want to load a file, make sure it is in the correct format
such as the ExamplePortfolio is and have it in your resources.

# 3 stocks vs 2 stocks portfolio
- First run the main function
- type CreatePortfolio
- choose a name for the portfolio and type it out.
- enter a date in the format of YYYY-MM-DD ex: 2020-01-01
- this will be your creation date
- enter another date, same format, to be your current date
- this could be today or any date past your creation date.

- enter AddStock
- type in name of the portfolio you just made
- enter ticker symbol
- enter quantity
- enter date of purchase in YYYY-MM-DD
- make sure your date is past the creation date, and before today.
- Repeat process two more times

- type return portfolio
- enter name of your portfolio
- enter the date of which you want to view,
- we usually use 2023-07-15
- this will return the summary on that date, the stock worth, the portfolio worth,
and every stock and how many shares it contains

- type return portfolio again
- follow same steps but with a different date to view

- if you'd like to persist this portfolio, type in SavePortfolio
- type in your portfolio name

- q to quit the program

- the only restrictions on dates are that dates to view must be after the creation date of your portfolio
- if you try to view your portfolio before that creation date, the value will be zero.
- any holiday or weekend where the market is closed is represented by the closing price of the most recent trading day.
- we will let the users know that the market is closed on those days as well.
- the data in the API ranges from 20 years ago, as long as your creation date is set up properly.


Our code currently handles all of the stocks available with the
Alpha Vantage API, so any stock ticker that is accepted in the US market.
