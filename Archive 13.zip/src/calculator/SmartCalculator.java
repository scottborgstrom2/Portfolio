package calculator;

/**
 * This class is for a smart calculator that extends the SimpleCalculator functionality.
 * It supports addition, subtraction, and multiplication.
 * It can handle additional advanced inputs while maintaining backward compatibility.
 * It ignores a leading '+' operator, and handles multiple equals and other specific cases.
 * It does not accept negative inputs but can handle negative results.
 */
public class SmartCalculator extends AbstractCalculator {
  private char lastOperator;
  private int lastOperand;

  /**
   * This function initializes the smart calculator.
   */
  public SmartCalculator() {
    super();
    this.lastOperator = '\0';
    this.lastOperand = 0;
  }

  protected void handleOperator(char input) {
    // handles a check for if the operator is the first input (except '+')
    if (currentInput.length() == 0 && !isResultDisplayed && !isOperatorSet) {
      if (input == '+') {
        return;
      } else {
        throw new IllegalArgumentException("Invalid input: operator "
                + "cannot be the first input except '+'");
      }
    }
    // handles if the result is currently displayed by starting a new equation
    if (isResultDisplayed) {
      currentOperator = input;
      isOperatorSet = true;
      inputSequence.setLength(0);
      inputSequence.append(result);
      inputSequence.append(input);
      isResultDisplayed = false;
      currentInput.setLength(0);
      // handles if an operator is already set
    } else if (isOperatorSet) {
      if (currentInput.length() == 0) {
        // Replace the last operator with the new one
        currentOperator = input;
        inputSequence.deleteCharAt(inputSequence.length() - 1);
        inputSequence.append(input);
      } else {
        int operand = Integer.parseInt(currentInput.toString());
        performOperation(operand);
        currentOperator = input;
        inputSequence.append(input);
        currentInput.setLength(0);
      }
      // handles if you need to set the current operator
    } else {
      currentOperator = input;
      isOperatorSet = true;
      inputSequence.append(input);
      result = lastValidOperand;
      currentInput.setLength(0);
    }
    hasOperandOverflowed = false;
  }

  // function for handling '=' input
  protected void handleEquals() {
    // handles if an operator is set and decides what to do based on if there is input
    if (isOperatorSet) {
      if (currentInput.length() == 0) {
        performOperation(lastValidOperand);
      } else {
        int operand = Integer.parseInt(currentInput.toString());
        performOperation(operand);
        lastOperand = operand;
      }
      // handles when no operator is set, there is no current input but we have a lastOperator
    } else if (!isOperatorSet && currentInput.length() == 0) {
      if (lastOperator != '\0') {
        repeatLastOperation();
      } else {
        throw new IllegalArgumentException("Invalid input sequence");
      }
      //handles when there is no operator set but there is current input
    } else if (!isOperatorSet && currentInput.length() > 0) {
      result = Integer.parseInt(currentInput.toString());
      // handles any other case
    } else {
      throw new IllegalArgumentException("Invalid input sequence");
    }
    // for updating the last operator
    if (currentOperator != '\0') {
      lastOperator = currentOperator;
    }

    // for reseting the operator and input sequence after handling equals
    currentOperator = '\0';
    isOperatorSet = false;
    currentInput.setLength(0);
    inputSequence.setLength(0);
    inputSequence.append(result);
    isResultDisplayed = true;
  }

  // input function
  @Override
  public Calculator input(char input) {
    if (Character.isDigit(input)) {
      handleNum(input);
      lastOperator = '\0';
    } else if (input == '+' || input == '-' || input == '*') {
      handleOperator(input);
      lastOperator = input;
    } else if (input == '=') {
      handleEquals();
    } else if (input == 'C') {
      clear();
    } else {
      throw new IllegalArgumentException("Invalid input");
    }
    return this;
  }

  // this method repeats the last operation
  private void repeatLastOperation() {
    switch (lastOperator) {
      case '+':
        result = safeAdd(result, lastOperand);
        break;
      case '-':
        result = safeSubtract(result, lastOperand);
        break;
      case '*':
        result = safeMultiply(result, lastOperand);
        break;
      default:
        throw new IllegalArgumentException("Invalid operator");
    }
  }

  // function that will preform a calculation based on the current operator.
  protected void performOperation(int operand) {
    switch (currentOperator) {
      case '+':
        result = safeAdd(result, operand);
        break;
      case '-':
        result = safeSubtract(result, operand);
        break;
      case '*':
        result = safeMultiply(result, operand);
        break;
      default:
        throw new IllegalArgumentException("Invalid operator");
    }
    lastValidOperand = operand;
    lastOperand = operand;
  }


  protected int safeAdd(int a, int b) {
    long result = (long) a + b;
    if (result > Integer.MAX_VALUE || result < Integer.MIN_VALUE) {
      return 0;
    }
    return (int) result;
  }

  protected int safeSubtract(int a, int b) {
    long result = (long) a - b;
    if (result > Integer.MAX_VALUE || result < Integer.MIN_VALUE) {
      return 0;
    }
    return (int) result;
  }

  protected int safeMultiply(int a, int b) {
    long result = (long) a * b;
    if (result > Integer.MAX_VALUE || result < Integer.MIN_VALUE) {
      return 0;
    }
    return (int) result;
  }

  // this function clears the calculator state
  protected void clear() {
    currentInput.setLength(0);
    inputSequence.setLength(0);
    result = 0;
    currentOperator = '\0';
    isOperatorSet = false;
    isResultDisplayed = false;
    lastValidOperand = 0;
    hasOperandOverflowed = false;
    lastOperator = '\0';
    lastOperand = 0;
  }
}