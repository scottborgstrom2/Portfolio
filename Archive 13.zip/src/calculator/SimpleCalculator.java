package calculator;

/**
 * this class is for a simple calculator that supports addition, subtraction, and multiplication.
 * It is not able to take negative numbers in as input but can handle them as results.
 * when a result is calculated it becomes an operand if any calculations are tried.
 *
 */
public class SimpleCalculator extends AbstractCalculator {

  /**
   * this function initializes the simple calculator.
   */
  public SimpleCalculator() {
    super();
  }

  // function for if the input was an operator
  protected void handleOperator(char input) {
    // check for if the operator is the first input
    if (currentInput.length() == 0 && !isResultDisplayed && !isOperatorSet) {
      throw new IllegalArgumentException("Invalid input: operator cannot be the first input");
    }
    // if the result is currently displayed start a new equation
    if (isResultDisplayed) {
      currentOperator = input;
      isOperatorSet = true;
      inputSequence.setLength(0);
      inputSequence.append(result);
      inputSequence.append(input);
      isResultDisplayed = false;
      currentInput.setLength(0);
      // if an operator is already set throw an error
    } else if (isOperatorSet) {
      if (currentInput.length() == 0) {
        throw new IllegalArgumentException(
                "Invalid sequence: operator cannot follow another operator");
      }
      int operand = Integer.parseInt(currentInput.toString());
      performOperation(operand);
      currentOperator = input;
      inputSequence.append(input);
      currentInput.setLength(0);
      // prepare for next operand
    } else {
      currentOperator = input;
      isOperatorSet = true;
      inputSequence.append(input);
      result = lastValidOperand;
      currentInput.setLength(0);
    }
    hasOperandOverflowed = false;
  }

  // function for when an equal sign is input
  protected void handleEquals() {
    if (isResultDisplayed) {
      return;
    }
    if (isOperatorSet && currentInput.length() > 0) {
      int operand = Integer.parseInt(currentInput.toString());
      try {
        performOperation(operand);
      } catch (IllegalArgumentException e) {
        result = 0;
      }
      isOperatorSet = false;
      currentInput.setLength(0);
      inputSequence.setLength(0);
      inputSequence.append(result);
      isResultDisplayed = true;
    } else {
      throw new IllegalArgumentException("Invalid sequence");
    }
  }

  @Override
  public Calculator input(char input) {
    if (Character.isDigit(input)) {
      handleNum(input);
    } else if (input == '+' || input == '-' || input == '*') {
      handleOperator(input);
    } else if (input == '=') {
      handleEquals();
    } else if (input == 'C') {
      clear();
    } else {
      throw new IllegalArgumentException("Invalid input");
    }
    return this;
  }

  // function that will preform a calculation based on the current operator.
  protected void performOperation(int operand) {
    switch (currentOperator) {
      case '+':
        result = safeAdd(result, operand);
        break;
      case '-':
        result = safeSubtract(result, operand);
        break;
      case '*':
        result = safeMultiply(result, operand);
        break;
      default:
        throw new IllegalArgumentException("Invalid operator");
    }
    lastValidOperand = operand;
  }


  protected int safeAdd(int a, int b) {
    long result = (long) a + b;
    if (result > Integer.MAX_VALUE || result < Integer.MIN_VALUE) {
      this.result = 0;
      throw new IllegalArgumentException("Result is too large");
    }
    return (int) result;
  }

  protected int safeSubtract(int a, int b) {
    long result = (long) a - b;
    if (result > Integer.MAX_VALUE || result < Integer.MIN_VALUE) {
      this.result = 0;
      throw new IllegalArgumentException("Result is too large");
    }
    return (int) result;
  }

  protected int safeMultiply(int a, int b) {
    long result = (long) a * b;
    if (result > Integer.MAX_VALUE || result < Integer.MIN_VALUE) {
      this.result = 0;
      throw new IllegalArgumentException("Result is too large");
    }
    return (int) result;
  }

  // function to handle clear
  protected void clear() {
    currentInput.setLength(0);
    inputSequence.setLength(0);
    result = 0;
    currentOperator = '\0';
    isOperatorSet = false;
    isResultDisplayed = false;
    lastValidOperand = 0;
    hasOperandOverflowed = false;
  }

}