package calculator;

/**
 * this class is for an abstract calculator represent the shared qualities of the
 *     smart calc and simple calc.
 */
public abstract class AbstractCalculator implements Calculator {
  protected StringBuilder currentInput;
  protected StringBuilder inputSequence;
  protected int result;
  protected char currentOperator;
  protected boolean isOperatorSet;
  protected boolean isResultDisplayed;
  protected int lastValidOperand;
  protected boolean hasOperandOverflowed;

  /**
   * this function initializes the abstract calculator.
   */
  public AbstractCalculator() {
    this.currentInput = new StringBuilder();
    this.inputSequence = new StringBuilder();
    this.result = 0;
    this.currentOperator = '\0';
    this.isOperatorSet = false;
    this.isResultDisplayed = false;
    this.lastValidOperand = 0;
    this.hasOperandOverflowed = false;
  }

  // returns a copy of inputSequence
  @Override
  public String getResult() {
    return inputSequence.toString();
  }

  // function to handle number input
  protected void handleNum(char input) {
    if (hasOperandOverflowed) {
      throw new IllegalArgumentException("Operand overflow");
    }
    if (isResultDisplayed) {
      clear();
    }
    currentInput.append(input);
    inputSequence.append(input);

    try {
      int operand = Integer.parseInt(currentInput.toString());
      lastValidOperand = operand;
    } catch (NumberFormatException e) {
      hasOperandOverflowed = true;
      currentInput.deleteCharAt(currentInput.length() - 1);
      inputSequence.deleteCharAt(inputSequence.length() - 1);
      throw new IllegalArgumentException("Operand overflow");
    }
  }

  // abstract function to handle operator
  protected abstract void handleOperator(char input);

  // abstract function to handle equals
  protected abstract void handleEquals();

  // abstract function to handle clear
  protected abstract void clear();

  // abstract function to safely handle addition
  protected abstract int safeAdd(int a, int b);

  // abstract function to safely handle subtraction
  protected abstract int safeSubtract(int a, int b);

  // abstract function to safely handle multiplication
  protected abstract int safeMultiply(int a, int b);

  // abstract function for preforming operations
  protected abstract void performOperation(int operand);
}