package calculator;

/**
 * Represents a simple calculator.
 */
public interface Calculator {

  /**
   * Processes a single character input.
   *
   * @param input this is a single character which represents
   *             a digit (0-9), an operator (+, -, *), or '='
   * @return the Calculator object after the input is properly handeled
   * @throws IllegalArgumentException will be thrown if the input is invalid
   */
  Calculator input(char input);

  /**
   * Returns the current result of the calculator.
   *
   * @return the current inputSequence / result as a String
   */
  String getResult();
}
