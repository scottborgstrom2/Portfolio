package calculator;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

/**
 * this class is for the tests for both the simple and smart calculator.
 */
public abstract class AbstractCalculatorTest {
  protected Calculator calc;

  abstract Calculator makeCalculator();

  @Before
  public void setUp() {
    calc = makeCalculator();
  }

  @Test
  public void testInitialization() {
    assertEquals("", calc.getResult());
  }

  @Test
  public void testSingleDigitInput() {
    calc.input('1');
    assertEquals("1", calc.getResult());
  }

  @Test
  public void testMultiDigitInput() {
    calc.input('1');
    calc.input('2');
    calc.input('3');
    assertEquals("123", calc.getResult());
  }

  @Test
  public void testOperandWithOperatorAndSecondOperand() {
    calc.input('1');
    calc.input('+');
    calc.input('3');
    assertEquals("1+3", calc.getResult());
  }

  @Test
  public void testOperandWithOperator() {
    calc.input('1');
    calc.input('+');
    assertEquals("1+", calc.getResult());
  }

  @Test
  public void testClearFunction() {
    calc.input('1');
    calc.input('2');
    calc.input('C');
    assertEquals("", calc.getResult());
  }

  @Test
  public void testAddition() {
    calc.input('1');
    calc.input('+');
    calc.input('2');
    calc.input('=');
    assertEquals("3", calc.getResult());
  }

  @Test
  public void testSubtraction() {
    calc.input('5');
    calc.input('-');
    calc.input('3');
    calc.input('=');
    assertEquals("2", calc.getResult());
  }

  @Test
  public void testMultiplication() {
    calc.input('4');
    calc.input('*');
    calc.input('2');
    calc.input('=');
    assertEquals("8", calc.getResult());
  }

  @Test
  public void testChainedOperations() {
    calc.input('3').input('2').input('+')
            .input('2').input('4').input('-')
            .input('1').input('0').input('*').input('2').input('=');
    assertEquals("92", calc.getResult());
  }

  @Test
  public void testClear() {
    calc.input('3');
    calc.input('2');
    calc.input('+');
    calc.input('2');
    calc.input('4');
    calc.input('C');
    assertEquals("", calc.getResult());
  }

  @Test
  public void testOperandOverflowThrowsException() {
    try {
      for (int i = 0; i < 11; i++) {
        calc.input('1');
      }
      fail("Expected an IllegalArgumentException to be thrown");
    } catch (IllegalArgumentException e) {
      // expected
    }
  }

  @Test
  public void testInvalidInputAlphabet() {
    try {
      calc.input('a');
      fail("Expected an IllegalArgumentException to be thrown");
    } catch (IllegalArgumentException e) {
      // Expected exception
    }
  }

  @Test
  public void testInvalidInputSymbol() {
    try {
      calc.input('@');
      fail("Expected an IllegalArgumentException to be thrown");
    } catch (IllegalArgumentException e) {
      // expected
    }
  }

  @Test
  public void testInvalidInputWhitespace() {
    try {
      calc.input(' ');
      fail("Expected an IllegalArgumentException to be thrown");
    } catch (IllegalArgumentException e) {
      // expected
    }
  }

  @Test
  public void testInvalidInputNewline() {
    try {
      calc.input('\n');
      fail("Expected an IllegalArgumentException to be thrown");
    } catch (IllegalArgumentException e) {
      // expected
    }
  }


  @Test
  public void testInvalidInput() {
    try {
      calc.input('3').input('2').input('+').input('2').input('4').input('@');
    } catch (IllegalArgumentException e) {
      // Expected exception
    }
    assertEquals("32+24", calc.getResult());
  }

  @Test
  public void testCorrectStringAfterOperator() {
    calc.input('3');
    calc.input('2');
    calc.input('+');
    assertEquals("32+", calc.getResult());
  }

}

