package calculator;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * This class contains the tests for the simplecalculator.
 */
public class SimpleCalculatorTest extends AbstractCalculatorTest {

  @Override
  Calculator makeCalculator() {
    return new SimpleCalculator();
  }

  @Before
  public void setUp() {
    calc = makeCalculator();
  }

  @Test
  public void testInvalidEquals() {
    try {
      calc.input('3');
      calc.input('2');
      calc.input('+');
      calc.input('=');
    } catch (IllegalArgumentException e) {
      // expected
    }
    assertEquals("32+", calc.getResult());
  }

  @Test
  public void testPlusAsFirstInput() {
    try {
      calc.input('+');
      calc.input('3');
      calc.input('2');
      calc.input('-');
      calc.input('1');
      calc.input('0');
      calc.input('=');
    } catch (IllegalArgumentException e) {
      assertEquals("", calc.getResult());
    }
  }

  @Test
  public void testSimpleCalculatorMultipleEqualsAfterThreeValidInputs() {
    try {
      calc.input('1');
      calc.input('2');
      calc.input('+');
      calc.input('3');
      calc.input('=');
      calc.input('=');
      calc.input('=');
    } catch (IllegalArgumentException e) {
      assertEquals("", calc.getResult());
    }
  }

  @Test
  public void testArithmeticOverflowResultsInZero() {
    calc.input('2').input('1').input('4').input('7').input('4')
            .input('8').input('3').input('6').input('4').input('7')
            .input('+').input('1').input('=');
    assertEquals("0", calc.getResult());
  }


  @Test(expected = IllegalArgumentException.class)
  public void testConsecutiveOperatorsThrowsException() {
    calc.input('3').input('+').input('+');
  }

  @Test
  public void testGetResultAfterFirstOperand() {
    calc.input('5');
    assertEquals("5", calc.getResult());
  }

  @Test
  public void testGetResultAfterOperator() {
    calc.input('5').input('+');
    assertEquals("5+", calc.getResult());
  }

  @Test
  public void testGetResultAfterSecondOperand() {
    calc.input('5').input('+').input('3');
    assertEquals("5+3", calc.getResult());
  }

  @Test
  public void testGetResultAfterOperatorRightAfterEquals() {
    calc.input('5').input('+').input('3').input('=');
    assertEquals("8", calc.getResult());
    calc.input('+');
    assertEquals("8+", calc.getResult());
  }

  @Test
  public void testOperatorInputAfterEquals() {
    calc.input('5');
    calc.input('+');
    calc.input('5');
    calc.input('=');
    calc.input('+');
    assertEquals("10+", calc.getResult());
  }
}
