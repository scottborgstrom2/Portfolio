package calculator;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * This class contains the tests for the smartcalculator.
 */
public class SmartCalculatorTest extends AbstractCalculatorTest {

  @Override
  Calculator makeCalculator() {
    return new SmartCalculator();
  }

  @Before
  public void setUp() {
    calc = makeCalculator();
  }

  @Test
  public void testEqualsAsSecondOperandFromAddition() {
    calc.input('3');
    calc.input('2');
    calc.input('+');
    calc.input('=');
    assertEquals("64", calc.getResult());
  }

  @Test
  public void testEqualsAsSecondOperandFromSubtraction() {
    calc.input('3');
    calc.input('2');
    calc.input('-');
    calc.input('=');
    assertEquals("0", calc.getResult());
  }

  @Test
  public void testPlusAsFirstInput() {
    calc.input('+');
    calc.input('3');
    calc.input('2');
    calc.input('-');
    calc.input('1');
    calc.input('0');
    calc.input('=');
    assertEquals("22", calc.getResult());
  }

  @Test
  public void testSmartCalculatorMultipleEqualsAfterThreeValidInputs() {
    calc.input('3');
    calc.input('2');
    calc.input('+');
    calc.input('2');
    calc.input('4');
    calc.input('=');
    calc.input('=');
    calc.input('=');
    assertEquals("104", calc.getResult());
  }

  @Test
  public void testMultipleEquals() {
    calc.input('3').input('2').input('+').input('2').input('4').input('=').input('=');
    assertEquals("80", calc.getResult());
  }

  @Test
  public void testArithmeticOverflowResultsInLastValidOperand() {
    try {
      calc.input('9').input('9').input('9').input('9').input('9').input('9').input('9');
      calc.input('9').input('9').input('9').input('*').input('9').input('=');
    } catch (IllegalArgumentException e) {
      assertEquals("999999999", calc.getResult());
    }
  }

  @Test
  public void testCorrectStringAfterEqualsAndOperator() {
    calc.input('3');
    calc.input('2');
    calc.input('+');
    calc.input('2');
    calc.input('4');
    calc.input('=');
    calc.input('+');
    assertEquals("56+", calc.getResult());
    calc.input('=');
    assertEquals("80", calc.getResult());
  }

  @Test
  public void testConsecutiveOperatorsThrowsException() {
    calc.input('3');
    calc.input('+');
    calc.input('+');
    calc.input('-');
    assertEquals("3-", calc.getResult());
  }
}
